'use strict';
require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3004;
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));
const uploadsDir = path.join(__dirname, 'uploads', 'checklist');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
function readJSON(filename, fallback) {
  if (fallback === undefined) fallback = [];
  try {
    const filepath = path.join(__dirname, 'data', filename);
    if (!fs.existsSync(filepath)) return fallback;
    return JSON.parse(fs.readFileSync(filepath, 'utf8'));
  } catch (err) { return fallback; }
}
function writeJSON(filename, data) {
  try {
    fs.writeFileSync(path.join(__dirname, 'data', filename), JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) { return false; }
}
app.get('/health', function(req, res) {
  res.json({ status: 'ok', env: process.env.NODE_ENV || 'staging', port: PORT, uptime: Math.floor(process.uptime()), timestamp: new Date().toISOString() });
});
app.get('/api/stores', function(req, res) {
  try { res.json({ success: true, data: readJSON('stores.json', []) }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/stores/am/:amName', function(req, res) {
  try {
    const stores = readJSON('stores.json', []);
    res.json({ success: true, data: stores.filter(function(s) { return s.am.toLowerCase() === req.params.amName.toLowerCase(); }) });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/checklist/:day', function(req, res) {
  try {
    const items = readJSON('checklist-items.json', {});
    const day = req.params.day.toLowerCase();
    res.json({ success: true, day: day, data: items[day] || [] });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/submissions', function(req, res) {
  try {
    const submissions = readJSON('submissions.json', []);
    const newSub = Object.assign({ id: Date.now().toString() }, req.body, { submittedAt: new Date().toISOString(), isLate: false });
    submissions.push(newSub);
    if (!writeJSON('submissions.json', submissions)) return res.status(500).json({ success: false, error: 'Failed to save' });
    res.json({ success: true, id: newSub.id });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/submissions', function(req, res) {
  try {
    let data = readJSON('submissions.json', []);
    if (req.query.am) data = data.filter(function(s) { return s.am === req.query.am; });
    if (req.query.day) data = data.filter(function(s) { return s.day === req.query.day; });
    if (req.query.store) data = data.filter(function(s) { return s.store === req.query.store; });
    res.json({ success: true, data: data, count: data.length });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/performance', function(req, res) {
  try {
    let data = readJSON('performance.json', []);
    if (req.query.am) data = data.filter(function(p) { return p.am === req.query.am; });
    res.json({ success: true, data: data });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/coverage', function(req, res) {
  try {
    let data = readJSON('coverage.json', []);
    if (req.query.am) data = data.filter(function(c) { return c.am === req.query.am; });
    if (req.query.month) data = data.filter(function(c) { return c.month === req.query.month; });
    res.json({ success: true, data: data });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/coverage', function(req, res) {
  try {
    const coverage = readJSON('coverage.json', []);
    const am = req.body.am, month = req.body.month, store = req.body.store, day = req.body.day;
    let amRec = null;
    for (var i = 0; i < coverage.length; i++) { if (coverage[i].am === am && coverage[i].month === month) { amRec = coverage[i]; break; } }
    if (!amRec) { amRec = { am: am, month: month, stores: [] }; coverage.push(amRec); }
    let storeRec = null;
    for (var j = 0; j < amRec.stores.length; j++) { if (amRec.stores[j].store === store) { storeRec = amRec.stores[j]; break; } }
    if (!storeRec) { storeRec = { store: store, wed: false, fri: false, sat: false, sun: false }; amRec.stores.push(storeRec); }
    if (day === 'wed' || day === 'fri' || day === 'sat' || day === 'sun') storeRec[day] = true;
    if (!writeJSON('coverage.json', coverage)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/posts', function(req, res) {
  try { res.json({ success: true, data: readJSON('posts.json', []) }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/posts', function(req, res) {
  try {
    const posts = readJSON('posts.json', []);
    const newPost = Object.assign({ id: Date.now().toString() }, req.body, { createdAt: new Date().toISOString(), pinned: false, reactions: {}, replies: [] });
    posts.unshift(newPost);
    if (!writeJSON('posts.json', posts)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true, data: newPost });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/timsy/chat', async function(req, res) {
  try {
    const sops = readJSON('timsy-sops.json', []);
    const sopContext = sops.map(function(s) { return 'MODULE: ' + s.module + ' ' + s.content; }).join(' --- ');
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-haiku-4-5-20251001', max_tokens: 400,
        system: 'You are Timsy, AI training assistant for Tim Hortons India. Answer only from SOPs. Under 150 words. End with: Need more help? Just ask! SOPs: ' + sopContext,
        messages: [{ role: 'user', content: req.body.message }] })
    });
    const data = await response.json();
    const reply = (data.content && data.content[0]) ? data.content[0].text : 'I will check with the ops team on that one.';
    res.json({ success: true, reply: reply });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/timsy/results', function(req, res) {
  try {
    const results = readJSON('timsy-results.json', []);
    const newResult = Object.assign({ id: Date.now().toString() }, req.body, { completedAt: new Date().toISOString() });
    results.push(newResult);
    if (!writeJSON('timsy-results.json', results)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true, data: newResult });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.use(function(req, res) {
  const p = path.join(__dirname, 'public', req.path.replace('/', '') + '.html');
  if (fs.existsSync(p)) { res.sendFile(p); } else { res.sendFile(path.join(__dirname, 'public', 'index.html')); }
});
app.listen(PORT, function() { console.log('OpsAIHub Staging running on port ' + PORT); });
module.exports = { readJSON: readJSON, writeJSON: writeJSON };
