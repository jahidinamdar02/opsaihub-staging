'use strict';
require('dotenv').config();
const nodemailer = require('nodemailer');
const multer = require('multer');
const express = require('express');
const path = require('path')
const cron = require('node-cron');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3004;
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Page-view usage logger ────────────────────────────────
const usageLog = path.join(__dirname, 'data', 'usage.log');
app.use(function(req, res, next) {
  if (req.path.endsWith('.html') || req.path === '/') {
    res.on('finish', function() {
      var ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.ip;
      var entry = new Date().toISOString() + ' | ' + res.statusCode + ' | ' + req.path + ' | ' + ip + ' | ' + (req.get('user-agent') || '-') + '\n';
      fs.appendFile(usageLog, entry, function(err) {
        if (err) console.error('usage log write failed:', err.message);
      });
    });
  }
  next();
});

// ── FY27 Targets API (must be before static middleware) ──
app.get('/api/fy27-targets', function(req, res) {
  try {
    var data = readJSON('fy27_targets.json', {});
    res.json(data);
  } catch(err) { res.status(500).json({ error: err.message }); }
});


// ── Delivery API (before static middleware) ──────────────
app.get('/api/delivery', function(req, res) {
  try {
    var data = readJSON('delivery.json', []);
    var month = req.query.month;
    if(month) data = data.filter(function(d){ return d.month === month; });
    res.json({ success:true, data:data });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});

app.post('/api/delivery', function(req, res) {
  try {
    var data = readJSON('delivery.json', []);
    var payload = req.body;
    payload.id = Date.now().toString();
    var idx = data.findIndex(function(d){ return d.store===payload.store && d.month===payload.month; });
    if(idx >= 0) data[idx] = payload;
    else data.push(payload);
    writeJSON('delivery.json', data);
    res.json({ success:true });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});


// ── FDU Dashboard APIs (before static) ───────────────────
app.get('/api/fdu/submissions', function(req, res) {
  try { res.json({ success:true, data:readJSON('fdu_submissions.json', []) }); }
  catch(err) { res.status(500).json({ success:false }); }
});

app.get('/api/fdu/donut-results', function(req, res) {
  try { res.json({ success:true, data:readJSON('fdu_donut_submissions.json', []) }); }
  catch(err) { res.status(500).json({ success:false }); }
});

const uploadsDir = path.join(__dirname, 'uploads', 'checklist');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
function readJSON(filename, fallback) {
  if (fallback === undefined) fallback = [];
  try {
    const filepath = path.join(__dirname, 'data', filename);
    if (!fs.existsSync(filepath)) return fallback;
    return JSON.parse(fs.readFileSync(filepath, 'utf8'));
  } catch (err) { return fallback; }
}
function writeJSON(filename, data) {
  try {
    fs.writeFileSync(path.join(__dirname, 'data', filename), JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) { return false; }
}

// ── AM Email Map ──────────────────────────────────────────
var AM_EMAILS = {
  'Raman':       'raman.kumar@timhortonsindia.com',
  'Harish':      'harish.solanki@timhortonsindia.com',
  'Rohit':       'rohit.gupta@timhortonsindia.com',
  'Deepak':      'deepak.kumar@timhortonsindia.com',
  'Sandeep Mukharjee':'sandeep.mukharjee@timhortonsindia.com',
  'Akash Rathod':'akash.rathod@timhortonsindia.com',
  'Jagadeesha':  'jagadeesha.shetty@timhortonsindia.com',
  'Shivam':      'shivam.singh@timhortonsindia.com',
  'Kajal':       'kajal.sharma@timhortonsindia.com',
  'TBA':         null,
  'Vrunda':      'trainingcentre.west@timhortonsindia.com'
};
var CC_EMAIL   = 'sandeep.yadav@timhortonsindia.com';
var HOD_EMAIL  = 'jahid.inamdar@timhortonsindia.com';
var CEO_EMAIL  = 'tarun.jain@timhortonsindia.com';
var TRAINING_EMAIL = 'trainingcentre.west@timhortonsindia.com';

var transporter = nodemailer.createTransport({
  host: 'smtp.hostinger.com',
  port: 465,
  secure: true,
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
});

function sendEmail(to, subject, html, callback) {
  transporter.sendMail({
    from: '"Tim\'s Ops Connect" <' + process.env.EMAIL_USER + '>',
    to: to,
    subject: subject,
    html: html
  }, function(err, info) {
    if (err) console.error('[Email error]', err.message);
    else console.log('[Email sent]', to);
    if (callback) callback(err);
  });
}

function emailStyle() {
  return '<style>body{margin:0;padding:0;background:#F5F5F7;font-family:Arial,sans-serif}' +
    '.wrap{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08)}' +
    '.hdr{background:linear-gradient(135deg,#C8102E,#8B0B1F);padding:24px 28px}' +
    '.hdr-logo{color:#fff;font-size:20px;font-weight:700}' +
    '.hdr-sub{color:rgba(255,255,255,0.7);font-size:13px;margin-top:4px}' +
    '.body{padding:24px 28px}' +
    '.greeting{font-size:20px;font-weight:700;color:#1C1C1E;margin-bottom:16px}' +
    '.card{background:#F5F5F7;border-radius:10px;padding:16px;margin-bottom:16px}' +
    '.card-ttl{font-size:11px;font-weight:700;color:#8E8E93;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px}' +
    '.card-val{font-size:28px;font-weight:700;color:#1C1C1E}' +
    '.card-val.green{color:#1B7A3A}.card-val.amber{color:#B36200}' +
    '.row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #E5E5EA}' +
    '.row:last-child{border-bottom:none}' +
    '.btn{display:block;background:#C8102E;color:#fff;text-decoration:none;text-align:center;padding:14px 24px;border-radius:8px;font-weight:700;font-size:14px;margin-top:16px}' +
    '.footer{padding:16px 28px;text-align:center;font-size:11px;color:#8E8E93;border-top:1px solid #E5E5EA}</style>';
}

function eRow(label, value, color) {
  return '<div class="row"><span style="font-size:13px;color:#1C1C1E">' + label + '</span>' +
    '<span style="font-size:12px;font-weight:700;color:' + (color || '#007AFF') + '">' + value + '</span></div>';
}

function eCard(title, content) {
  return '<div class="card"><div class="card-ttl">' + title + '</div>' + content + '</div>';
}

function eBtn(text, url) {
  return '<a href="' + url + '" class="btn">' + text + '</a>';
}

function eWrap(body, logoText, subtitle) {
  return emailStyle() + '<div class="wrap">' +
    '<div class="hdr"><div class="hdr-logo">' + (logoText || "Tim's Ops Connect") + '</div>' +
    (subtitle ? '<div class="hdr-sub">' + subtitle + '</div>' : '') + '</div>' +
    '<div class="body">' + body + '</div>' +
    '<div class="footer">Tim Hortons India &middot; OpsAIHub</div></div>';
}

function generateBriefing(callback) {
  try {
    var { GoogleGenerativeAI } = require('@google/generative-ai');
    var genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    var model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    var sales = readJSON('sales_summary.json', {});
    var submissions = readJSON('submissions.json', []);
    var today = new Date();
    var todaySubs = submissions.filter(function(s) {
      return new Date(s.submittedAt || s.timestamp || 0).toDateString() === today.toDateString();
    });
    var context = 'Sales summary: ' + JSON.stringify(sales).substring(0, 400) +
      ' | Submissions today: ' + todaySubs.length + ' | Date: ' + today.toLocaleDateString('en-IN');
    model.generateContent('Generate a concise daily ops briefing for Tim Hortons India OpsAIHub. Under 150 words. Include key metrics and one action item. Context: ' + context)
    .then(function(resp) {
      var text = resp.response ? resp.response.text() : 'System running normally. Check dashboard for latest data.';
      callback(null, text);
    }).catch(function() {
      callback(null, 'System running normally. Check dashboard for latest data.');
    });
  } catch(e) {
    callback(null, 'System running normally. Check dashboard for latest data.');
  }
}

function sendSubmissionEmail(submission, callback) {
  var amEmail = AM_EMAILS[submission.am] || null;
  if (!amEmail) { if(callback) callback(null); return; }
  var day = (submission.day || '').toUpperCase();
  var store = submission.store || 'Unknown Store';
  var am = submission.am || 'AM';
  var score = submission.score || 'N/A';
  var date = submission.date || new Date().toISOString().slice(0,10);
  var subject = '[Tim\'s Ops Connect] ' + day + ' Checklist Submitted — ' + store;
  var html = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">' +
    '<div style="background:#C8102E;padding:20px;border-radius:8px 8px 0 0">' +
    '<h2 style="color:#fff;margin:0">Tim\'s Ops Connect &#9749;</h2></div>' +
    '<div style="background:#f5f5f7;padding:20px;border-radius:0 0 8px 8px">' +
    '<h3 style="color:#1D1D1F;margin-top:0">' + day + ' Checklist — ' + store + '</h3>' +
    '<table style="width:100%;border-collapse:collapse">' +
    '<tr><td style="padding:8px;border-bottom:1px solid #E5E5EA;color:#6E6E73">AM</td><td style="padding:8px;border-bottom:1px solid #E5E5EA;font-weight:600">' + am + '</td></tr>' +
    '<tr><td style="padding:8px;border-bottom:1px solid #E5E5EA;color:#6E6E73">Store</td><td style="padding:8px;border-bottom:1px solid #E5E5EA;font-weight:600">' + store + '</td></tr>' +
    '<tr><td style="padding:8px;border-bottom:1px solid #E5E5EA;color:#6E6E73">Date</td><td style="padding:8px;border-bottom:1px solid #E5E5EA;font-weight:600">' + date + '</td></tr>' +
    '<tr><td style="padding:8px;color:#6E6E73">Score</td><td style="padding:8px;font-weight:600;color:#C8102E">' + score + '%</td></tr>' +
    '</table>' +
    '<p style="color:#6E6E73;font-size:12px;margin-top:16px">This is an automated confirmation from Tim\'s Ops Connect. View full data at staging.opsaihub.in</p>' +
    '</div></div>';
  var mailOptions = {
    from: '"Tim\'s Ops Connect" <' + process.env.EMAIL_USER + '>',
    to: amEmail,
    cc: [CC_EMAIL],
    subject: subject,
    html: html
  };
  transporter.sendMail(mailOptions, function(err, info) {
    if (err) { console.error('Email error:', err.message); }
    else { console.log('Email sent to', amEmail); }
    if (callback) callback(err);
  });
}




// ── WEEKLY AM HEATMAP BUILDER ─────────────────────────────
function buildWeeklyHeatmap(label, startDate, endDate) {
  var subs       = readJSON('submissions.json', []);
  var storesData = readJSON('stores.json', []);

  var periodSubs = subs.filter(function(s) {
    var d = new Date(s.submittedAt || s.date || 0);
    return d >= startDate && d <= endDate;
  });

  var amList   = Object.keys(AM_EMAILS).filter(function(am) { return AM_EMAILS[am]; });
  var weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  var amData = {};
  amList.forEach(function(am) {
    var amStores      = storesData.filter(function(s) { return s.am === am; }).map(function(s) { return s.name; });
    var visitedStores = {};
    var activeDays    = {};

    periodSubs.filter(function(s) { return s.am === am; }).forEach(function(s) {
      if (s.store) visitedStores[s.store] = true;
      var d = new Date(s.date || s.submittedAt || 0);
      activeDays[(d.getDay() + 6) % 7] = true; // Mon=0 … Sun=6
    });

    var scores           = periodSubs.filter(function(s) { return s.am === am && s.score; }).map(function(s) { return s.score; });
    var storesCovered    = Object.keys(visitedStores).length;
    var totalStores      = amStores.length;
    // Thu = index 3 in Mon-0 system; exclude it from expected working days (day off)
    var activeDaysExclThu = Object.keys(activeDays).filter(function(k) { return parseInt(k) !== 3; }).length;
    var WORKING_DAYS     = 6; // Mon Tue Wed Fri Sat Sun
    var visitAchievePct  = Math.round(activeDaysExclThu / WORKING_DAYS * 100);

    amData[am] = {
      stores:           amStores,
      visitedStores:    visitedStores,
      activeDays:       activeDays,
      visitsCount:      periodSubs.filter(function(s) { return s.am === am; }).length,
      storesCovered:    storesCovered,
      totalStores:      totalStores,
      coveragePct:      totalStores > 0 ? Math.round(storesCovered / totalStores * 100) : 0,
      avgScore:         scores.length > 0 ? Math.round(scores.reduce(function(a, b) { return a + b; }, 0) / scores.length) : null,
      activeDaysExclThu: activeDaysExclThu,
      visitAchievePct:  visitAchievePct
    };
  });

  var totalVisits    = periodSubs.length;
  var allStoreCount  = storesData.length;
  var visitedSet     = {};
  periodSubs.forEach(function(s) { if (s.store) visitedSet[s.store] = true; });
  var overallCovPct  = allStoreCount > 0 ? Math.round(Object.keys(visitedSet).length / allStoreCount * 100) : 0;
  var amActiveCount  = amList.filter(function(am) { return amData[am].visitsCount > 0; }).length;

  function scColor(v) {
    return v === null ? '#8E8E93' : v >= 80 ? '#1B7A3A' : v >= 50 ? '#B36200' : '#C8102E';
  }

  var cellBase  = 'text-align:center;padding:6px 5px;font-size:10px;font-weight:700;border:2px solid #fff;';
  var headerTh  = 'padding:7px 10px;background:#EBEBED;font-size:11px;font-weight:700;color:#3C3C43;text-align:center;white-space:nowrap;border:2px solid #fff;';
  var amTh      = 'padding:7px 12px;background:#EBEBED;font-size:11px;font-weight:700;color:#3C3C43;text-align:left;white-space:nowrap;border-right:2px solid #E5E5EA;';
  var tblStyle  = 'border-collapse:separate;border-spacing:2px;width:100%;';
  var secStyle  = 'background:#F5F5F7;border-radius:10px;padding:16px;margin-bottom:16px;overflow-x:auto;';
  var secTitle  = 'font-size:11px;font-weight:700;color:#8E8E93;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px;';

  // Store coverage rows — each AM row shows their assigned stores as coloured cells
  var storeCoverageRows = amList.map(function(am) {
    var d = amData[am];
    var storeCells = d.stores.length > 0
      ? d.stores.map(function(store) {
          var visited   = !!d.visitedStores[store];
          var shortName = store.length > 13 ? store.substring(0, 12) + '…' : store;
          return '<td style="' + cellBase + 'background:' + (visited ? '#D1F2D9' : '#FFE5E5') + ';color:' + (visited ? '#1B7A3A' : '#9B1A1A') + ';min-width:58px;" title="' + store + '">'
            + shortName + '</td>';
        }).join('')
      : '<td style="' + cellBase + 'color:#8E8E93;">&mdash;</td>';

    var scoreStr = d.avgScore !== null ? d.avgScore + '%' : '&mdash;';
    // Store coverage %: unique stores visited this week vs total assigned
    var covPctStr = d.totalStores > 0 ? d.storesCovered + '/' + d.totalStores + ' (' + d.coveragePct + '%)' : '&mdash;';
    return '<tr>'
      + '<td style="padding:7px 12px;font-size:13px;font-weight:700;color:#1C1C1E;white-space:nowrap;border-right:2px solid #E5E5EA;background:#fff;">' + am + '</td>'
      + storeCells
      + '<td style="' + cellBase + 'background:#fff;color:' + scColor(d.coveragePct) + ';border-left:2px solid #E5E5EA;font-size:12px;white-space:nowrap;">' + covPctStr + '</td>'
      + '<td style="' + cellBase + 'background:#fff;color:' + scColor(d.avgScore) + ';font-size:12px;">' + scoreStr + '</td>'
      + '</tr>';
  }).join('');

  // Day activity heatmap rows — Thu (index 3) is weekly day off, excluded from achievement
  var dayRows = amList.map(function(am) {
    var d        = amData[am];
    var dayCells = weekDays.map(function(day, i) {
      if (i === 3) { // Thursday — day off
        return '<td style="' + cellBase + 'background:#F0F0F0;color:#8E8E93;">Off</td>';
      }
      var active = !!d.activeDays[i];
      return '<td style="' + cellBase + 'background:' + (active ? '#D1F2D9' : '#FFE5E5') + ';color:' + (active ? '#1B7A3A' : '#C8102E') + ';">'
        + (active ? '&#10003;' : '&mdash;') + '</td>';
    }).join('');
    var pct = d.visitAchievePct;
    var activeColor = scColor(pct);
    var achieveStr  = d.activeDaysExclThu + '/6 (' + pct + '%)';
    return '<tr>'
      + '<td style="padding:7px 12px;font-size:13px;font-weight:700;color:#1C1C1E;white-space:nowrap;border-right:2px solid #E5E5EA;background:#fff;">' + am + '</td>'
      + dayCells
      + '<td style="' + cellBase + 'background:#fff;color:' + activeColor + ';border-left:2px solid #E5E5EA;font-size:12px;white-space:nowrap;">' + achieveStr + '</td>'
      + '</tr>';
  }).join('');

  return emailStyle()
    + '<div class="wrap">'
    + '<div class="hdr" style="background:linear-gradient(135deg,#1C1C1E,#3A3A3C);">'
      + '<div class="hdr-logo">Weekly AM Heatmap</div>'
      + '<div class="hdr-sub">Activity Summary &mdash; ' + label + '</div>'
    + '</div>'
    + '<div class="body">'

    // Summary cards
    + '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;">'
      + '<div style="flex:1;min-width:90px;background:#F5F5F7;border-radius:10px;padding:14px;text-align:center;">'
        + '<div style="font-size:11px;font-weight:700;color:#8E8E93;text-transform:uppercase;letter-spacing:0.4px;">AMs Active</div>'
        + '<div style="font-size:26px;font-weight:800;color:' + scColor(Math.round(amActiveCount / amList.length * 100)) + ';margin-top:4px;">' + amActiveCount + '<span style="font-size:14px;color:#8E8E93;">/' + amList.length + '</span></div>'
      + '</div>'
      + '<div style="flex:1;min-width:90px;background:#F5F5F7;border-radius:10px;padding:14px;text-align:center;">'
        + '<div style="font-size:11px;font-weight:700;color:#8E8E93;text-transform:uppercase;letter-spacing:0.4px;">Store Coverage</div>'
        + '<div style="font-size:26px;font-weight:800;color:' + scColor(overallCovPct) + ';margin-top:4px;">' + overallCovPct + '<span style="font-size:14px;color:#8E8E93;">%</span></div>'
      + '</div>'
      + '<div style="flex:1;min-width:90px;background:#F5F5F7;border-radius:10px;padding:14px;text-align:center;">'
        + '<div style="font-size:11px;font-weight:700;color:#8E8E93;text-transform:uppercase;letter-spacing:0.4px;">Total Visits</div>'
        + '<div style="font-size:26px;font-weight:800;color:#007AFF;margin-top:4px;">' + totalVisits + '</div>'
      + '</div>'
    + '</div>'

    // Store coverage heatmap
    + '<div style="' + secStyle + '">'
      + '<div style="' + secTitle + '">Store Visit Coverage &mdash; Last Week</div>'
      + '<table style="' + tblStyle + '">'
        + '<thead><tr>'
          + '<th style="' + amTh + '">Area Manager</th>'
          + '<th style="' + headerTh + '" colspan="20">Assigned Stores &nbsp; (green&nbsp;=&nbsp;visited &nbsp; red&nbsp;=&nbsp;not visited this week)</th>'
          + '<th style="' + headerTh + 'border-left:2px solid #E5E5EA;">Visited / Assigned (%)</th>'
          + '<th style="' + headerTh + '">Checklist Avg Score</th>'
        + '</tr></thead>'
        + '<tbody>' + storeCoverageRows + '</tbody>'
      + '</table>'
    + '</div>'

    // Day activity heatmap
    + '<div style="' + secStyle + '">'
      + '<div style="' + secTitle + '">Daily Visit Compliance &mdash; Last Week &nbsp;(Expected: 1 store visit/day &bull; Thursday = Day Off)</div>'
      + '<table style="' + tblStyle + '">'
        + '<thead><tr>'
          + '<th style="' + amTh + '">Area Manager</th>'
          + weekDays.map(function(d, i) { return '<th style="' + headerTh + (i===3?'color:#8E8E93;':'') + '">' + d + (i===3?' (Off)':'') + '</th>'; }).join('')
          + '<th style="' + headerTh + 'border-left:2px solid #E5E5EA;">Days Active / 6 (%)</th>'
        + '</tr></thead>'
        + '<tbody>' + dayRows + '</tbody>'
      + '</table>'
    + '</div>'

    + '<p style="font-size:11px;color:#8E8E93;text-align:center;margin-top:4px;">Green ≥80% &nbsp;&middot;&nbsp; Amber 50–79% &nbsp;&middot;&nbsp; Red &lt;50% &nbsp;&middot;&nbsp; Thursday excluded (weekly off) &nbsp;&middot;&nbsp; Data window: Mon–Sun last week</p>'
    + '<a href="https://staging.opsaihub.in/hod.html" class="btn">Open HOD Dashboard &rarr;</a>'
    + '</div>'
    + '<div class="footer">Tim Hortons India &middot; OpsAIHub &middot; Weekly automated heatmap</div>'
    + '</div>';
}

// ── CEO / WEEKLY REPORT BUILDER ───────────────────────────
function buildCeoReport(label, startDate, endDate) {
  var subs      = readJSON('submissions.json', []);
  var fduSubs   = readJSON('fdu_submissions.json', []);
  var donutSubs = readJSON('fdu_donut_submissions.json', []);
  var storesData= readJSON('stores.json', []);
  var totalStores = storesData.length;

  function inPeriod(s) {
    var d = new Date(s.submittedAt || s.date || 0);
    return d >= startDate && d <= endDate;
  }

  var periodSubs  = subs.filter(inPeriod);
  var periodFdu   = fduSubs.filter(inPeriod);
  var periodDonut = donutSubs.filter(inPeriod);

  // ── per-AM checklist stats ──
  var amStats = {};
  Object.keys(AM_EMAILS).forEach(function(am) {
    var n = storesData.filter(function(s){ return s.am === am; }).length;
    amStats[am] = { am: am, visits: 0, scores: [], storesCovered: {}, totalStores: n };
  });
  periodSubs.forEach(function(s) {
    if (!amStats[s.am]) return;
    amStats[s.am].visits++;
    amStats[s.am].scores.push(s.score || 0);
    amStats[s.am].storesCovered[s.store] = true;
  });
  Object.values(amStats).forEach(function(a) {
    a.avgScore = a.visits > 0
      ? Math.round(a.scores.reduce(function(x,y){return x+y;},0) / a.visits)
      : null;
    a.covered  = Object.keys(a.storesCovered).length;
    a.coveragePct = a.totalStores > 0 ? Math.round(a.covered / a.totalStores * 100) : 0;
  });
  var amRanked = Object.values(amStats).sort(function(a, b) {
    if (a.avgScore === null && b.avgScore === null) return 0;
    if (a.avgScore === null) return 1;
    if (b.avgScore === null) return -1;
    return b.avgScore - a.avgScore;
  });

  // ── FDU display compliance ──
  var fduStoreSet = {};
  periodFdu.forEach(function(s){ fduStoreSet[s.store] = true; });
  var fduStoreCount = Object.keys(fduStoreSet).length;
  var fduPct = Math.round(fduStoreCount / totalStores * 100);
  var fduByAm = {};
  Object.keys(AM_EMAILS).forEach(function(am){ fduByAm[am] = { submissions: 0 }; });
  periodFdu.forEach(function(s){ if (fduByAm[s.am]) fduByAm[s.am].submissions++; });

  // ── Donut quality ──
  var donutTotal = periodDonut.length;
  var donutPass  = periodDonut.filter(function(s){ return s.overallPass === true; }).length;
  var donutFail  = periodDonut.filter(function(s){ return s.overallPass === false; }).length;
  var donutPct   = donutTotal > 0 ? Math.round(donutPass / donutTotal * 100) : 0;

  // ── score color helpers ──
  function sc(v) { return v===null?'#8E8E93':v>=85?'#1B7A3A':v>=60?'#B36200':'#C8102E'; }
  function badge(v, label) {
    var col = v>=85?'#D1F2D9:#1B7A3A':v>=60?'#FFF3CD:#B36200':'#FFE5E5:#C8102E';
    var bg=col.split(':')[0], fg=col.split(':')[1];
    return '<span style="background:'+bg+';color:'+fg+';padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;">'+(label||v+'%')+'</span>';
  }
  function row(left, right, rightColor) {
    return '<div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #E5E5EA;align-items:center">'
      +'<span style="font-size:13px;color:#1C1C1E">'+left+'</span>'
      +'<span style="font-size:12px;font-weight:700;color:'+(rightColor||'#007AFF')+'">'+right+'</span></div>';
  }
  function card(title, content) {
    return '<div style="background:#F5F5F7;border-radius:10px;padding:16px;margin-bottom:16px">'
      +'<div style="font-size:11px;font-weight:700;color:#8E8E93;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">'+title+'</div>'
      +content+'</div>';
  }
  function medal(i) { return i===0?'🥇':i===1?'🥈':i===2?'🥉':'#'+(i+1); }

  // ── AM leaderboard block ──
  var amRows = amRanked.map(function(a, i) {
    var score = a.avgScore !== null ? a.avgScore+'%' : '—';
    var cvg   = a.covered+'/'+a.totalStores+' stores';
    return '<div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;margin-bottom:3px;background:'+(i===0?'#F0FFF4':'#fff')+';">'
      +'<span style="font-size:18px;width:26px;text-align:center">'+medal(i)+'</span>'
      +'<div style="flex:1">'
        +'<div style="font-size:13px;font-weight:700;color:#1C1C1E">'+a.am+'</div>'
        +'<div style="font-size:11px;color:#8E8E93">'+a.visits+' visits &nbsp;·&nbsp; '+cvg+' &nbsp;·&nbsp; Coverage: '+a.coveragePct+'%</div>'
      +'</div>'
      +'<div style="font-size:14px;font-weight:800;color:'+sc(a.avgScore)+'">'+score+'</div>'
    +'</div>';
  }).join('');

  // ── FDU per-AM rows ──
  var fduAmRows = Object.keys(fduByAm).map(function(am) {
    var n = fduByAm[am].submissions;
    return row(am, n > 0 ? n+' submissions' : '— None', n > 0 ? '#1B7A3A' : '#C8102E');
  }).join('');

  // ── AMs with zero activity ──
  var inactive = amRanked.filter(function(a){ return a.visits === 0 && fduByAm[a.am] && fduByAm[a.am].submissions === 0; });
  var inactiveBlock = inactive.length > 0
    ? '<div style="background:#FFF8E1;border-left:3px solid #F59E0B;border-radius:0 8px 8px 0;padding:12px 14px;margin-top:4px;font-size:13px;color:#78350F;">'
      +'⚠️ <strong>No activity recorded for:</strong> '+inactive.map(function(a){return a.am;}).join(', ')+'</div>'
    : '<div style="background:#F0FFF4;border-left:3px solid #22C55E;border-radius:0 8px 8px 0;padding:10px 14px;font-size:13px;color:#14532D;">✅ All AMs recorded activity this period.</div>';

  var totalVisits = periodSubs.length;
  var submittedAmCount = amRanked.filter(function(a){return a.visits>0;}).length;
  var teamAvg = submittedAmCount > 0
    ? Math.round(amRanked.filter(function(a){return a.avgScore!==null;}).reduce(function(s,a){return s+a.avgScore;},0) / submittedAmCount)
    : 0;

  var body = emailStyle()
    +'<div class="wrap">'
    +'<div class="hdr"><div class="hdr-logo">Tim\'s Ops Connect ☕</div>'
    +'<div class="hdr-sub">Operations Report &mdash; '+label+'</div></div>'
    +'<div class="body">'

    // Intro
    +'<div style="font-size:20px;font-weight:700;color:#1C1C1E;margin-bottom:12px">Operations Update — '+label+'</div>'
    +'<p style="font-size:14px;color:#3C3C43;line-height:1.6;margin-bottom:20px">Summary of area manager store visits, checklist compliance, and FDU display discipline for the period <strong>'+label+'</strong>.</p>'

    // Headline stats
    +'<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px">'
      +'<div style="flex:1;min-width:120px;background:#F5F5F7;border-radius:10px;padding:14px;text-align:center">'
        +'<div style="font-size:30px;font-weight:800;color:'+sc(teamAvg)+'">'+teamAvg+'%</div>'
        +'<div style="font-size:11px;color:#8E8E93;margin-top:4px;">Team Avg Checklist</div></div>'
      +'<div style="flex:1;min-width:120px;background:#F5F5F7;border-radius:10px;padding:14px;text-align:center">'
        +'<div style="font-size:30px;font-weight:800;color:#007AFF">'+totalVisits+'</div>'
        +'<div style="font-size:11px;color:#8E8E93;margin-top:4px;">Total Store Visits</div></div>'
      +'<div style="flex:1;min-width:120px;background:#F5F5F7;border-radius:10px;padding:14px;text-align:center">'
        +'<div style="font-size:30px;font-weight:800;color:'+sc(fduPct)+'">'+fduPct+'%</div>'
        +'<div style="font-size:11px;color:#8E8E93;margin-top:4px;">FDU Store Coverage</div></div>'
      +'<div style="flex:1;min-width:120px;background:#F5F5F7;border-radius:10px;padding:14px;text-align:center">'
        +'<div style="font-size:30px;font-weight:800;color:'+sc(donutPct)+'">'+donutPct+'%</div>'
        +'<div style="font-size:11px;color:#8E8E93;margin-top:4px;">Donut Quality Pass</div></div>'
    +'</div>'

    // AM leaderboard
    +card('📋 Area Manager Checklist Performance — '+label, amRows)
    +inactiveBlock

    // FDU discipline
    +'<div style="margin-top:16px">'
    +card('🖼️ FDU Display Discipline',
        row('Stores submitted FDU photos', fduStoreCount+' / '+totalStores, sc(fduPct))
      + row('Submission rate', fduPct+'%', sc(fduPct))
      + row('Total FDU submissions', periodFdu.length+'', '#007AFF')
      + '<div style="border-top:1px solid #E5E5EA;margin-top:8px;padding-top:8px;font-size:11px;font-weight:700;color:#8E8E93;text-transform:uppercase;letter-spacing:0.4px;margin-bottom:6px">By Area Manager</div>'
      + fduAmRows
    )

    // Donut quality
    +card('🍩 Donut Quality Checks',
        row('Total quality checks', donutTotal+'', '#007AFF')
      + row('Passed', donutPass+'', '#1B7A3A')
      + row('Failed', donutFail+'', '#C8102E')
      + row('Pass rate', donutPct+'%', sc(donutPct))
      + (donutTotal === 0 ? '<div style="font-size:12px;color:#8E8E93;margin-top:8px;">No donut quality check submissions for this period.</div>' : '')
    )
    +'</div>'

    +'<a href="https://opsaihub.in" class="btn">View Live Dashboard &rarr;</a>'
    +'</div>'
    +'<div class="footer">Tim Hortons India &middot; OpsAIHub &middot; Automated Ops Report</div>'
    +'</div>';

  return body;
}

// ── KPI Data Routes ───────────────────────────────────────
app.get('/api/kpi/:month', function(req, res) {
  var month = req.params.month;
  var allowed = ['feb2026','mar2026'];
  if (allowed.indexOf(month) === -1) return res.status(400).json({error:'Invalid month'});
  try {
    var data = readJSON('kpi_'+month+'.json', {});
    res.json(data);
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});


app.get('/api/issues', function(req, res) {
  try { res.json({ success:true, data: readJSON('issues.json', []) }); }
  catch(e) { res.status(500).json({ success:false, error:e.message }); }
});


app.get('/api/health-scores', function(req, res) {
  try { res.json({ success:true, data: (readJSON('health_scores.json', {})).stores || [] }); }
  catch(e) { res.status(500).json({ success:false, error:e.message }); }
});


app.get('/api/audits', function(req, res) {
  try { res.json({ success:true, data: readJSON('audits.json', {audits:[]}) }); }
  catch(e) { res.status(500).json({ success:false, error:e.message }); }
});

app.post('/api/audits', function(req, res) {
  try {
    var data = readJSON('audits.json', {audits:[]});
    var entry = req.body;
    entry.id = Date.now().toString();
    entry.submittedAt = new Date().toISOString();
    // Remove existing entry for same store+cycle+type if exists
    data.audits = data.audits.filter(function(a){
      return !(a.store === entry.store && a.cycle === entry.cycle && a.type === entry.type);
    });
    data.audits.push(entry);
    writeJSON('audits.json', data);
    res.json({ success:true, id: entry.id });
  } catch(e) { res.status(500).json({ success:false, error:e.message }); }
});


app.get('/api/world-events', function(req, res) {
  try {
    var data = readJSON('world_events.json', {events:[]});
    res.json({ success:true, data: data.events, lastUpdated: data.lastUpdated });
  } catch(e) { res.status(500).json({ success:false, error:e.message }); }
});
app.get('/health', function(req, res) {
  res.json({ status: 'ok', env: process.env.NODE_ENV || 'staging', port: PORT, uptime: Math.floor(process.uptime()), timestamp: new Date().toISOString() });
});
app.get('/api/stores', function(req, res) {
  try { res.json({ success: true, data: readJSON('stores.json', []) }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/stores/am/:amName', function(req, res) {
  try {
    const stores = readJSON('stores.json', []);
    res.json({ success: true, data: stores.filter(function(s) { return s.am.toLowerCase() === req.params.amName.toLowerCase(); }) });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/checklist/:day', function(req, res) {
  try {
    const items = readJSON('checklist-items.json', {});
    const day = req.params.day.toLowerCase();
    res.json({ success: true, day: day, data: items[day] || [] });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/submissions', function(req, res) {
  try {
    var submissions = readJSON('submissions.json', []);
    var submission = req.body;
    // Add timestamp if missing
    if (!submission.submittedAt) {
      submission.submittedAt = new Date().toISOString();
    }
    if (!submission.date) {
      submission.date = new Date().toISOString().slice(0,10);
    }
    // Generate ID if missing
    if (!submission.id) {
      submission.id = Date.now().toString();
    }
    // Check for duplicate (same day + store + date)
    var dupIdx = submissions.findIndex(function(s) {
      return s.day === submission.day && 
             s.store === submission.store && 
             s.date === submission.date;
    });
    if (dupIdx >= 0) {
      submissions[dupIdx] = submission; // Update existing
    } else {
      submissions.push(submission);
    }
    writeJSON('submissions.json', submissions);
    // Send email confirmation (non-blocking)
    try {
      sendSubmissionEmail(submission, null);
    } catch(emailErr) {
      console.error('Email send error:', emailErr.message);
    }
    res.json({ success: true, id: submission.id, message: 'Submission saved' });
    // Check weekly top 3 and fire auto-recognition post if needed
    setImmediate(function() { try { checkWeeklyTop3AutoPost(submission.am); } catch(e) { console.error('AutoPost error:', e.message); } });
  } catch(err) {
    console.error('Submission error:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/submissions', function(req, res) {
  try {
    let data = readJSON('submissions.json', []);
    if (req.query.am) data = data.filter(function(s) { return s.am === req.query.am; });
    if (req.query.day) data = data.filter(function(s) { return s.day === req.query.day; });
    if (req.query.store) data = data.filter(function(s) { return s.store === req.query.store; });
    res.json({ success: true, data: data, count: data.length });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/performance', function(req, res) {
  try {
    let data = readJSON('performance.json', []);
    if (req.query.am) data = data.filter(function(p) { return p.am === req.query.am; });
    res.json({ success: true, data: data });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/coverage', function(req, res) {
  try {
    var all = readJSON('coverage.json', []);
    var am = req.query.am;
    var month = req.query.month;
    var filtered = all;
    if(am) filtered = filtered.filter(function(c){ return c.am === am; });
    if(month) {
      var monthFiltered = filtered.filter(function(c){ return c.month === month; });
      // If no data for requested month, fall back to most recent month
      if(monthFiltered.length === 0 && filtered.length > 0) {
        filtered.sort(function(a,b){ return b.month.localeCompare(a.month); });
        var latestMonth = filtered[0].month;
        monthFiltered = filtered.filter(function(c){ return c.month === latestMonth; });
        res.json({ success:true, data:monthFiltered, note:'No data for '+month+', showing '+latestMonth });
        return;
      }
      filtered = monthFiltered;
    }
    res.json({ success:true, data:filtered });
  } catch(e) { res.status(500).json({ success:false, error:e.message }); }
});

app.post('/api/coverage', function(req, res) {
  try {
    const coverage = readJSON('coverage.json', []);
    const am = req.body.am, month = req.body.month, store = req.body.store, day = req.body.day;
    let amRec = null;
    for (var i = 0; i < coverage.length; i++) { if (coverage[i].am === am && coverage[i].month === month) { amRec = coverage[i]; break; } }
    if (!amRec) { amRec = { am: am, month: month, stores: [] }; coverage.push(amRec); }
    let storeRec = null;
    for (var j = 0; j < amRec.stores.length; j++) { if (amRec.stores[j].store === store) { storeRec = amRec.stores[j]; break; } }
    if (!storeRec) { storeRec = { store: store, wed: false, fri: false, sat: false, sun: false }; amRec.stores.push(storeRec); }
    if (day === 'wed' || day === 'fri' || day === 'sat' || day === 'sun') storeRec[day] = true;
    if (!writeJSON('coverage.json', coverage)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/posts', function(req, res) {
  try { res.json({ success: true, data: readJSON('posts.json', []) }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/posts', function(req, res) {
  try {
    const posts = readJSON('posts.json', []);
    const newPost = Object.assign({ id: Date.now().toString() }, req.body, { createdAt: new Date().toISOString(), pinned: false, reactions: {}, replies: [] });
    posts.unshift(newPost);
    if (!writeJSON('posts.json', posts)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true, data: newPost });
    // Fire-and-forget: Jahid auto-comment (email blast disabled)
    setImmediate(function() { jahidAutoComment(newPost); });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// ── Jahid Auto-Comment Engine ─────────────────────────────────────────────────
function jahidAutoComment(post) {
  try {
    // Skip auto-posts from the recognition engine (Jahid doesn't comment on his own posts)
    if (post.isAutoPost || post.author === 'Jahid') return;

    var caption = (post.caption || '').toLowerCase();
    var category = (post.category || '').toLowerCase();
    var author = post.author || 'team';

    // Category-specific comment pools
    var pools = {
      recognition: [
        '🏆 This is what excellence looks like! So proud of you, ' + author + ' — keep setting the bar! 🔥',
        '👏 Absolutely love seeing this! ' + author + ', you\'re an inspiration to the whole network. Keep it up! ⭐',
        '🥇 Recognition well deserved! This is exactly the culture we\'re building — thank you, ' + author + '! 💪',
        '🎊 So proud of this! ' + author + ', the team is lucky to have you. Keep shining! ✨',
      ],
      celebration: [
        '🎉 Love this energy! Celebrations like this is what keeps us going as a team! Great work, ' + author + '! ☕🙌',
        '🥳 Yes yes yes!! This is the Tim Hortons spirit right here! Amazing, ' + author + '! 🔥',
        '🎊 Big moments deserve big celebrations — so happy for you, ' + author + '! Keep this energy flowing! 💫',
        '🙌 Love it!! This is exactly what Tim\'s culture looks like. Celebrate this one, ' + author + '! 🎉',
      ],
      bestpractice: [
        '💡 Brilliant share, ' + author + '! This is gold for the whole network — tagging everyone to learn from this! 📌',
        '🤩 Now THIS is how we raise the bar! Amazing practice, ' + author + '. Let\'s make this standard across all stores! 💪',
        '👏 Love when we share knowledge like this! ' + author + ', you\'re making the whole team smarter. Thank you! 🌟',
        '📌 Pinning this in my mind! Excellent insight, ' + author + '. The network needs more of this! 🙌',
      ],
      coffee: [
        '☕ Nothing beats a great coffee moment! Looks amazing, ' + author + '! This is why we do what we do 😍',
        '😍 That looks incredible! ' + author + ', Tim\'s at its best right there! ☕🔥',
        '🫶 Pure joy in a cup! Love seeing the passion, ' + author + '! This is what Tim\'s India is all about ☕',
        '☕ This made my day! The love for the craft is real — keep it up, ' + author + '! 🌟',
      ],
      teamwin: [
        '💪 TEAM WIN!! This is what we grind for!! Huge shoutout to everyone involved — incredible, ' + author + '! 🏆🔥',
        '🙌 Team wins are the BEST wins! So proud of this, ' + author + '. You all smashed it! 💥',
        '🎯 This is the standard! When the team wins, everyone wins. Amazing work, ' + author + ' and the whole crew! 🥇',
        '🔥 Love this!! Nothing fires me up more than a team win! Outstanding, ' + author + '! Keep pushing! 💪',
      ],
      other: [
        '❤️ Love seeing activity on the feed! Keep sharing, ' + author + ' — this is how we stay connected as a team! 🙌',
        '🤩 Great share, ' + author + '! This is what our community feed is all about! Keep it coming! ☕',
        '💬 Love this! ' + author + ', you\'re keeping the team vibe alive — appreciate you! 🙏✨',
        '👀 Noticed this immediately! Great stuff, ' + author + '. The feed comes alive when you share like this! 🔥',
      ]
    };

    // Keyword overrides — caption-based tone adjustments
    var comment;
    if (/checklist|audit|compli/i.test(caption)) {
      var checklistReplies = [
        '✅ Checklist done right — ' + author + ', this is how standards are upheld! Proud of this! 🙌',
        '📋 ' + author + ', the attention to detail here is next level! This is what audit-ready looks like! 💪',
        '✅ Consistency is the key — and ' + author + ' has it locked in! Great work! 🏆',
      ];
      comment = checklistReplies[Math.floor(Math.random() * checklistReplies.length)];
    } else if (/store|clean|display|merchandis/i.test(caption)) {
      var storeReplies = [
        '🏪 Store standards on point! ' + author + ', this is exactly what our guests deserve to walk into! 🔥',
        '✨ That store looks immaculate! ' + author + ', world-class execution — this is what pride looks like! 👏',
        '🙌 This is the Tim Hortons standard! ' + author + ', every store in the network should look like this! 💫',
      ];
      comment = storeReplies[Math.floor(Math.random() * storeReplies.length)];
    } else if (/sales|target|number|revenue|growth/i.test(caption)) {
      var salesReplies = [
        '📈 Numbers don\'t lie — and this one tells a great story! Brilliant, ' + author + '! 🏆',
        '🚀 When the work is right, the results follow! Amazing performance, ' + author + '! Keep pushing! 💥',
        '🎯 Targets hit! This is what consistency looks like — so proud of this, ' + author + '! 🔥',
      ];
      comment = salesReplies[Math.floor(Math.random() * salesReplies.length)];
    } else if (/team|staff|crew|people/i.test(caption)) {
      var teamReplies = [
        '🫶 People-first culture — this is what it looks like in action! Love this, ' + author + '! 🙌',
        '❤️ The team is everything! ' + author + ', you\'re building something special here. Keep nurturing it! 💪',
        '👨‍👩‍👧‍👦 This is the Tim\'s family right here! Love seeing the team spirit, ' + author + '! 🏆',
      ];
      comment = teamReplies[Math.floor(Math.random() * teamReplies.length)];
    } else {
      // Fall back to category pool
      var pool = pools[category] || pools.other;
      comment = pool[Math.floor(Math.random() * pool.length)];
    }

    // Inject the comment into the post
    var posts = readJSON('posts.json', []);
    var idx = posts.findIndex(function(p) { return p.id === post.id; });
    if (idx === -1) return;
    if (!posts[idx].comments) posts[idx].comments = [];
    posts[idx].comments.push({
      author: 'Jahid',
      text: comment,
      time: 'Just now'
    });
    writeJSON('posts.json', posts);
  } catch (e) {
    console.error('jahidAutoComment error:', e.message);
  }
}

function sendFeedPostEmail(post) {
  var catEmojis = { recognition:'🏆', celebration:'🎉', bestpractice:'💡', coffee:'☕', teamwin:'💪', other:'💬' };
  var catLabels = { recognition:'Recognition', celebration:'Celebration', bestpractice:'Best Practice', coffee:'Coffee Moment', teamwin:'Team Win', other:'Share' };
  var emoji = catEmojis[post.category] || '☕';
  var catLabel = catLabels[post.category] || 'Post';
  var caption = (post.caption || '').replace(/<[^>]+>/g, '').slice(0, 200) + ((post.caption||'').length > 200 ? '...' : '');
  var author = post.author || 'A teammate';
  var store = post.store ? ' · ' + post.store : '';
  var html = '<div style="font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:480px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.1);">'
    + '<div style="background:#C8102E;padding:20px 24px;">'
    + '<div style="color:#fff;font-size:22px;font-weight:800;">Tim\'s Feed ☕</div>'
    + '<div style="color:rgba(255,255,255,0.8);font-size:13px;margin-top:4px;">New post from the team</div>'
    + '</div>'
    + '<div style="padding:24px;">'
    + '<div style="font-size:32px;margin-bottom:10px;">' + emoji + '</div>'
    + '<div style="font-size:16px;font-weight:700;color:#1D1D1F;">' + author + ' posted in Tim\'s Feed</div>'
    + '<div style="font-size:12px;color:#6E6E73;margin-top:4px;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;">' + catLabel + store + '</div>'
    + '<div style="background:#F5F5F7;border-radius:12px;padding:14px;margin:16px 0;font-size:14px;color:#1D1D1F;line-height:1.6;">' + caption + '</div>'
    + (post.photo && post.photo.length > 5 ? '<img src="https://opsaihub.in' + post.photo + '" style="width:100%;border-radius:12px;margin-bottom:16px;object-fit:cover;max-height:300px;" alt="Post photo">' : '')
    + '<a href="https://opsaihub.in/feed.html" style="display:inline-block;background:#C8102E;color:#fff;border-radius:12px;padding:12px 24px;font-size:14px;font-weight:700;text-decoration:none;">View Post on Tim\'s Feed →</a>'
    + '</div>'
    + '<div style="padding:14px 24px;background:#F5F5F7;font-size:11px;color:#8E8E93;">Tim\'s Ops Connect · Tim Hortons India</div>'
    + '</div>';
  sendEmail(AM_EMAILS['Jahid'], '[Tim\'s Feed] ' + author + ' just posted — ' + catLabel, html, function(){});
}

// ── AM Profile Pictures ───────────────────────────────────────────────────────
var profileUpload = multer({ storage: multer.diskStorage({ destination: 'uploads/profiles/', filename: function(req, file, cb) { cb(null, Date.now() + '-' + Math.random().toString(36).substr(2,6) + '.jpg'); } }), limits: { fileSize: 8 * 1024 * 1024 } });

app.get('/api/am-profiles', function(req, res) {
  try { res.json({ success: true, data: readJSON('am_profiles.json', {}) }); }
  catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.post('/api/am-profile/upload', profileUpload.single('photo'), function(req, res) {
  try {
    if (!req.file) return res.status(400).json({ success: false, error: 'No file' });
    var am = (req.body.am || '').trim();
    if (!am) return res.status(400).json({ success: false, error: 'am name required' });
    var url = '/uploads/profiles/' + req.file.filename;
    var profiles = readJSON('am_profiles.json', {});
    profiles[am] = url;
    if (!writeJSON('am_profiles.json', profiles)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true, url: url });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.use('/uploads/profiles', require('express').static('uploads/profiles'));
app.post('/api/timsy/chat', async function(req, res) {
  try {
    const sops = readJSON('timsy-sops.json', []);
    const sopContext = sops.map(function(s) { return 'MODULE: ' + s.module + ' ' + s.content; }).join(' --- ');
    const { GoogleGenerativeAI } = require('@google/generative-ai');
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash', systemInstruction: 'You are Timsy, AI training assistant for Tim Hortons India. Answer only from SOPs. Under 150 words. End with: Need more help? Just ask! SOPs: ' + sopContext });
    const data = await model.generateContent(req.body.message);
    const reply = data.response ? data.response.text() : 'I will check with the ops team on that one.';
    res.json({ success: true, reply: reply });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/timsy/results', function(req, res) {
  try {
    const results = readJSON('timsy-results.json', []);
    const newResult = Object.assign({ id: Date.now().toString() }, req.body, { completedAt: new Date().toISOString() });
    results.push(newResult);
    if (!writeJSON('timsy-results.json', results)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true, data: newResult });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
// ── Products API ─────────────────────────────────────────
app.get('/api/products', function(req, res) {
  try { res.json({ success:true, data:readJSON('products.json', []) }); }
  catch(err) { res.status(500).json({ success:false, error:err.message }); }
});
app.post('/api/products', function(req, res) {
  try {
    var data = readJSON('products.json', []);
    data.unshift(req.body);
    writeJSON('products.json', data);
    res.json({ success:true });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});

// ── Projects API ─────────────────────────────────────────
app.get('/api/projects', function(req, res) {
  try { res.json({ success:true, data:readJSON('projects.json', []) }); }
  catch(err) { res.status(500).json({ success:false, error:err.message }); }
});
app.post('/api/projects', function(req, res) {
  try {
    var data = readJSON('projects.json', []);
    data.push(req.body);
    writeJSON('projects.json', data);
    res.json({ success:true });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});

// ── Timsy Results API ─────────────────────────────────────
app.get('/api/timsy/results', function(req, res) {
  try { res.json({ success:true, data:readJSON('timsy-results.json', []) }); }
  catch(err) { res.status(500).json({ success:false, error:err.message }); }
});

// ── Training API ─────────────────────────────────────────
app.get('/api/training', function(req, res) {
  try { res.json({ success:true, data:readJSON('training.json', []) }); }
  catch(err) { res.status(500).json({ success:false, error:err.message }); }
});
app.post('/api/training', function(req, res) {
  try {
    var data = readJSON('training.json', []);
    var payload = req.body;
    var idx = data.findIndex(function(d){ return d.store===payload.store; });
    if(idx>=0) data[idx]=payload; else data.push(payload);
    writeJSON('training.json', data);
    res.json({ success:true });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});

// ── Feed APIs ─────────────────────────────────────────────
app.post('/api/posts/react', function(req, res) {
  try {
    var posts = readJSON('posts.json', []);
    var post = posts.find(function(p){ return p.id === req.body.postId; });
    if(post) {
      if(!post.reactions) post.reactions = {};
      post.reactions[req.body.emoji] = req.body.count;
      writeJSON('posts.json', posts);
    }
    res.json({ success:true });
  } catch(err) { res.json({ success:false }); }
});

app.post('/api/posts/comment', function(req, res) {
  try {
    var posts = readJSON('posts.json', []);
    var post = posts.find(function(p){ return p.id === req.body.postId; });
    if(post) {
      if(!post.comments) post.comments = [];
      post.comments.push(req.body.comment);
      writeJSON('posts.json', posts);
    }
    res.json({ success:true });
  } catch(err) { res.json({ success:false }); }
});

app.post('/api/feed/upload', multer({storage:require('multer').diskStorage({destination:'uploads/feed/',filename:function(req,file,cb){cb(null,Date.now()+'-'+Math.random().toString(36).substr(2,9)+'.jpg');}}),limits:{fileSize:10*1024*1024}}).single('photo'), function(req, res) {
  try {
    if(!req.file) return res.json({ success:false });
    res.json({ success:true, url:'/uploads/feed/'+req.file.filename });
  } catch(err) { res.json({ success:false }); }
});


// ── FDU APIs ─────────────────────────────────────────────
app.get('/api/fdu/donut-sop', function(req, res) {
  try {
    var sop = readJSON('donut_sop.json', {});
    var today = new Date().toISOString().substring(0,10);
    if(sop.todaysPick && sop.todaysPick.date === today) {
      return res.json({ success:true, donut1:sop.todaysPick.donut1, donut2:sop.todaysPick.donut2, date:today });
    }
    var donuts = (sop.donuts || []).filter(function(d){ return !d.discontinued; });
    if(donuts.length < 2) return res.json({ success:false, error:'Not enough donuts' });
    var shuffled = donuts.slice().sort(function(){ return Math.random()-0.5; });
    var pick = { date:today, donut1:shuffled[0], donut2:shuffled[1] };
    sop.todaysPick = pick;
    writeJSON('donut_sop.json', sop);
    res.json({ success:true, donut1:pick.donut1, donut2:pick.donut2, date:today });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});

app.post('/api/fdu/submit', multer({storage:require('multer').diskStorage({destination:'uploads/fdu/',filename:function(req,file,cb){cb(null,Date.now()+'-'+Math.random().toString(36).substr(2,9)+'.jpg');}}),limits:{fileSize:30*1024*1024}}).fields([{name:'photo'}]), async function(req, res) {
  try {
    var now = new Date();
    var ist = new Date(now.getTime() + 5.5*60*60*1000);
    var cutoff = new Date(ist); cutoff.setHours(11,30,0,0);
    var onTime = ist <= cutoff;
    var entry = {
      id: Date.now().toString(),
      store: req.body.store || '',
      am: (req.body.am||'').replace('Area Manager: ','').trim(),
      submittedAt: now.toISOString(),
      onTime: onTime,
      photos: req.files && req.files.photo ? ['/uploads/fdu/'+req.files.photo[0].filename] : [],
      topRow:'', midRow:'', timbits:'', water:'', tags:'',
      topRowFeedback:'', midRowFeedback:'', timbitsFeedback:'', waterFeedback:'', tagsFeedback:'',
      overallPass: false, summary: ''
    };
    try {
      var { GoogleGenerativeAI } = require('@google/generative-ai');
      var sharp = require('sharp');
      var genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
      var client = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      var photoPath = req.files && req.files.photo ? req.files.photo[0].path : null;
      var msgParts = [];
      if(photoPath && fs.existsSync(photoPath)) {
        var imgBuf = await sharp(photoPath).resize(1200,1600,{fit:'inside'}).jpeg({quality:70}).toBuffer();
        msgParts.push({ inlineData:{ mimeType:'image/jpeg', data:imgBuf.toString('base64') }});
      }
      msgParts.push({ text:'You are a strict Tim Hortons India FDU quality inspector. Inspect this FDU display photo against these exact SOPs: 1. TOP ROW (Dream Donuts): minimum 3 donuts in EACH basket. 2. MIDDLE ROW (Classic Donuts): minimum 2 donuts in EACH basket. 3. TIMBITS ROW: minimum 10 timbits in EACH basket. 4. BOTTOM SHELF: minimum 8 Tim Hortons water bottles upright centered labels forward. 5. TAGS: all price/name tags present neat and visible. Count carefully. Partial compliance = FAIL. Be specific about which basket fails. Respond ONLY in valid JSON no markdown no extra text: {"topRow":"Pass or Fail","midRow":"Pass or Fail","timbits":"Pass or Fail","water":"Pass or Fail","tags":"Pass or Fail","topRowFeedback":"one sentence","midRowFeedback":"one sentence","timbitsFeedback":"one sentence","waterFeedback":"one sentence","tagsFeedback":"one sentence","overallPass":true or false,"summary":"one sentence"}'});
      var resp = await client.generateContent(msgParts);
      var raw = resp.response.text().trim().replace(/^```json\s*/i,'').replace(/^```/,'').replace(/```$/,'').trim();
      var parsed = JSON.parse(raw);
      entry.topRow = parsed.topRow||'Pass';
      entry.midRow = parsed.midRow||'Pass';
      entry.timbits = parsed.timbits||'Pass';
      entry.water = parsed.water||'Pass';
      entry.tags = parsed.tags||'Pass';
      entry.topRowFeedback = parsed.topRowFeedback||'';
      entry.midRowFeedback = parsed.midRowFeedback||'';
      entry.timbitsFeedback = parsed.timbitsFeedback||'';
      entry.waterFeedback = parsed.waterFeedback||'';
      entry.tagsFeedback = parsed.tagsFeedback||'';
      entry.overallPass = parsed.overallPass !== false;
      entry.summary = parsed.summary||'';
    } catch(aiErr) {
      console.error('FDU AI grading error:', aiErr.message);
      entry.topRow='Submitted'; entry.midRow='Submitted';
      entry.timbits='Submitted'; entry.water='Submitted'; entry.tags='Submitted';
      entry.overallPass=true; entry.summary='Photo submitted. Manual review pending.';
    }
    var data = readJSON('fdu_submissions.json', []);
    data.push(entry);
    writeJSON('fdu_submissions.json', data);
    res.json({ success:true, onTime:onTime, entry:entry });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});
app.post('/api/fdu/donut-submit', multer({storage:require('multer').diskStorage({destination:'uploads/fdu/',filename:function(req,file,cb){cb(null,Date.now()+'-'+Math.random().toString(36).substr(2,9)+'.jpg');}}),limits:{fileSize:20*1024*1024}}).fields([{name:'photo1'},{name:'photo2'}]), async function(req, res) {
  try {
    var sop = readJSON('donut_sop.json', {});
    var pick = sop.todaysPick || {};
    var d1 = pick.donut1 || {};
    var d2 = pick.donut2 || {};
    var entry = {
      id: Date.now().toString(),
      store: req.body.store || '',
      am: req.body.am || '',
      submittedAt: new Date().toISOString(),
      donut1: { id: d1.id||'', name: d1.name||'', standards: d1.standards||'' },
      donut2: { id: d2.id||'', name: d2.name||'', standards: d2.standards||'' },
      photo1: req.files && req.files.photo1 ? '/uploads/fdu/'+req.files.photo1[0].filename : '',
      photo2: req.files && req.files.photo2 ? '/uploads/fdu/'+req.files.photo2[0].filename : '',
      grade1: '', grade2: '', feedback1: '', feedback2: '', overallPass: true, summary: ''
    };
    try {
      var { GoogleGenerativeAI } = require('@google/generative-ai');
      var genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
      var client = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      var waterStd='Minimum 6 Tim Hortons water bottles upright on bottom FDU shelf, labels forward, no gaps, clean.';
      var textPrompt = 'You are a strict Tim Hortons India QSR quality inspector. Grade each item ONLY against its exact SOP standards. Be strict — partial compliance is a FAIL.' +
        ' DONUT 1 — ' + entry.donut1.name + ' (' + (entry.donut1.type||'') + '). SOP STANDARDS: ' + entry.donut1.standards +
        ' DONUT 2 — ' + entry.donut2.name + ' (' + (entry.donut2.type||'') + '). SOP STANDARDS: ' + entry.donut2.standards +
        ' WATER BOTTLES — Check Photo 1 (FDU display). SOP STANDARDS: ' + waterStd +
        ' For each donut: check coating evenness, topping/drizzle count and pattern, quantity in basket (min 3), shape and finish.' +
        ' For water bottles: count visible bottles (min 6), check upright position, label visibility, gaps.' +
        ' Respond ONLY in valid JSON, no markdown: {"grade1":"Pass or Fail","grade2":"Pass or Fail","waterBottles":"Pass or Fail","feedback1":"specific one sentence citing exact SOP deviation if fail","feedback2":"specific one sentence citing exact SOP deviation if fail","feedbackWater":"one sentence on water bottle compliance","overallPass":true or false,"summary":"one sentence overall"}';
      var msgParts = [];
      var photo1Path = req.files && req.files.photo1 ? req.files.photo1[0].path : null;
      var photo2Path = req.files && req.files.photo2 ? req.files.photo2[0].path : null;
      var sharp = require('sharp');
      if (photo1Path && fs.existsSync(photo1Path)) {
        var img1Buf = await sharp(photo1Path).resize(1200, 1600, { fit: 'inside' }).jpeg({ quality: 70 }).toBuffer();
        msgParts.push({ inlineData: { mimeType: 'image/jpeg', data: img1Buf.toString('base64') } });
      }
      if (photo2Path && fs.existsSync(photo2Path)) {
        var img2Buf = await sharp(photo2Path).resize(1200, 1600, { fit: 'inside' }).jpeg({ quality: 70 }).toBuffer();
        msgParts.push({ inlineData: { mimeType: 'image/jpeg', data: img2Buf.toString('base64') } });
      }
      msgParts.push({ text: textPrompt });
      var resp = await client.generateContent(msgParts);
      var rawText = resp.response.text().trim();
      rawText = rawText.replace(/^```json\s*/i,'').replace(/^```\s*/i,'').replace(/\s*```$/,'').trim();
      var parsed = JSON.parse(rawText);
      entry.grade1 = parsed.grade1 || 'Pass';
      entry.grade2 = parsed.grade2 || 'Pass';
      entry.waterBottles = parsed.waterBottles || 'Submitted';
      entry.feedback1 = parsed.feedback1 || '';
      entry.feedback2 = parsed.feedback2 || '';
      entry.feedbackWater = parsed.feedbackWater || '';
      entry.overallPass = parsed.overallPass !== false;
      entry.summary = parsed.summary || '';
    } catch(aiErr) {
      console.error('AI grading error:', aiErr.message);
      entry.grade1 = 'Submitted';
      entry.grade2 = 'Submitted';
      entry.feedback1 = 'Photo received. Manual review pending.';
      entry.feedback2 = 'Photo received. Manual review pending.';
      entry.overallPass = null;
      entry.pendingReview = true;
      entry.summary = 'Photos submitted successfully for review.';
    }
    var data = readJSON('fdu_donut_submissions.json', []);
    data.push(entry);
    writeJSON('fdu_donut_submissions.json', data);
    res.json({ success: true, entry: entry });
  } catch(err) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/fdu/am-summary', function(req, res) {
  try {
    var subs = readJSON('fdu_donut_submissions.json', []);
    var stats = {};
    subs.forEach(function(s) {
      var am = s.am || 'Unknown';
      if (!stats[am]) stats[am] = { am: am, total: 0, passed: 0, failed: 0, stores: {} };
      stats[am].total++;
      var pass = s.overallPass === true || s.grade1 === 'Pass' || s.grade2 === 'Pass';
      if (pass) stats[am].passed++;
      else stats[am].failed++;
      if (s.store) stats[am].stores[s.store] = true;
    });
    var result = Object.values(stats).map(function(a) {
      return {
        am: a.am,
        total: a.total,
        passed: a.passed,
        failed: a.failed,
        passRate: a.total > 0 ? Math.round(a.passed/a.total*100) : 0,
        storeCount: Object.keys(a.stores).length
      };
    });
    res.json({ success:true, data:result });
  } catch(err) { res.status(500).json({ success:false, error:err.message }); }
});

app.get('/api/fdu/links', function(req, res) {
  try { res.json({ success:true, data:readJSON('fdu_links.json', []) }); }
  catch(err) { res.status(500).json({ success:false }); }
});

// EVENTS MODULE — Submission + Retrieval + Compliance
// ════════════════════════════════════════════════════════════
var eventUpload = multer({
  dest: 'uploads/events/',
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: function(req, file, cb){
    if(file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Images only'));
  }
}).array('images', 3);

app.post('/api/events/submit', function(req, res){
  eventUpload(req, res, function(err){
    if(err) return res.status(400).json({success:false, error:err.message});
    try {
      var b = req.body;
      var images = (req.files||[]).map(function(f){
        // Rename to preserve extension for browser rendering
        var ext = (f.originalname||'').split('.').pop().toLowerCase();
        var newName = f.filename + (ext?'.'+ext:'');
        var oldPath = 'uploads/events/'+f.filename;
        var newPath = 'uploads/events/'+newName;
        try{ require('fs').renameSync(oldPath, newPath); } catch(e){}
        return '/uploads/events/'+newName;
      });

      // Validate mandatory fields
      var required = ['am','store','eventDate','venue','menuPricing','salesGenerated','revenueShare','otherExpenses','manualBillBook','manualBillBookComment','punchedInSystem','punchedInSystemComment','billsAttached','billsAttachedComment','managerPresent'];
      var missing = required.filter(function(k){ return !b[k] || b[k].toString().trim() === ''; });
      if(missing.length > 0) return res.status(400).json({success:false, error:'Missing required fields: '+missing.join(', ')});
      if(images.length === 0) return res.status(400).json({success:false, error:'At least 1 image is required'});

      // Calculate profit
      var sales = parseFloat(b.salesGenerated)||0;
      var expenses = parseFloat(b.otherExpenses)||0;
      var commission = parseFloat(b.revenueShare)||0;
      var revenueShare  = sales * (commission / 100);  // % Revenue Share / Rentals (AM-entered)
            var foodCost     = sales * 0.30;                 // 30% Food Cost
            var rental       = sales * 0.05;                 // 5% Expenses
            var commCharge   = sales * 0.02;                 // 2% Commission
            var bankCharges  = sales * 0.02;                 // 2% Bank Charges
            var profit = sales - revenueShare - foodCost - rental - commCharge - bankCharges - expenses;

      // Compliance score
      var complianceItems = ['manualBillBook','punchedInSystem','billsAttached'];
      var complianceYes = complianceItems.filter(function(k){ return b[k]==='yes'; }).length;
      var complianceScore = Math.round(complianceYes/complianceItems.length*100);

      var record = {
        id: Date.now().toString(),
        am: b.am,
        store: b.store,
        region: b.region,
        eventDate: b.eventDate,
        venue: b.venue,
        menuPricing: b.menuPricing,
        customPrice: b.customPrice||null,
        salesGenerated: sales,
        revenueSharePct: commission,
        otherExpenses: expenses,
        profit: Math.round(profit),
        compliance: {
          manualBillBook: { answer: b.manualBillBook, comment: b.manualBillBookComment },
          punchedInSystem: { answer: b.punchedInSystem, comment: b.punchedInSystemComment },
          billsAttached: { answer: b.billsAttached, comment: b.billsAttachedComment },
          managerPresent: b.managerPresent,
          score: complianceScore
        },
        images: images,
        notes: b.notes||'',
        submittedAt: new Date().toISOString()
      };

      var data = readJSON('event_submissions.json', {submissions:[]});
      if(!data.submissions) data.submissions = [];
      data.submissions.push(record);
      data.lastUpdated = new Date().toISOString();
      writeJSON('event_submissions.json', data);

      res.json({success:true, id:record.id, profit:record.profit, complianceScore:complianceScore});
    } catch(e){ res.status(500).json({success:false, error:e.message}); }
  });
});

app.post('/api/events/quick', function(req, res){
  try {
    var b = req.body;
    var required = ['am','store','eventName','eventDate','salesGenerated'];
    var missing = required.filter(function(k){ return !b[k] || b[k].toString().trim() === ''; });
    if(missing.length > 0) return res.status(400).json({success:false, error:'Missing: '+missing.join(', ')});
    var sales = parseFloat(b.salesGenerated)||0;
    var commission = parseFloat(b.revenueShare)||0;
    var expenses = parseFloat(b.otherExpenses)||0;
    var revenueShare = sales * (commission / 100);
    var foodCost     = sales * 0.30;
    var rental       = sales * 0.05;
    var commCharge   = sales * 0.02;
    var bankCharges  = sales * 0.02;
    var profit = Math.round(sales - revenueShare - foodCost - rental - commCharge - bankCharges - expenses);
    var record = {
      id: Date.now().toString(),
      am: b.am.trim(),
      store: b.store.trim(),
      eventName: b.eventName.trim(),
      eventDate: b.eventDate,
      venue: b.eventName.trim(),
      menuPricing: 'standard',
      salesGenerated: sales,
      revenueSharePct: commission,
      otherExpenses: expenses,
      profit: profit,
      compliance: { score: 0 },
      images: [],
      notes: b.notes||'',
      submittedAt: new Date().toISOString()
    };
    var data = readJSON('event_submissions.json', {submissions:[]});
    if(!data.submissions) data.submissions = [];
    data.submissions.push(record);
    data.lastUpdated = new Date().toISOString();
    writeJSON('event_submissions.json', data);
    res.json({success:true, id:record.id, profit:profit, profitPct: sales>0?Math.round(profit/sales*100):0});
  } catch(e){ res.status(500).json({success:false, error:e.message}); }
});

app.get('/api/events', function(req, res){
  try {
    var data = readJSON('event_submissions.json', {submissions:[]});
    var subs = data.submissions||[];
    // Filter params
    if(req.query.am) subs = subs.filter(function(s){return s.am===req.query.am;});
    if(req.query.month) subs = subs.filter(function(s){return s.eventDate&&s.eventDate.startsWith(req.query.month);});
    subs = subs.sort(function(a,b){return new Date(b.eventDate)-new Date(a.eventDate);});
    res.json({success:true, data:subs, total:subs.length});
  } catch(e){ res.status(500).json({success:false, error:e.message}); }
});

app.get('/api/events/:id', function(req, res){
  try {
    var data = readJSON('event_submissions.json', {submissions:[]});
    var event = (data.submissions||[]).find(function(s){return s.id===req.params.id;});
    if(!event) return res.status(404).json({success:false, error:'Not found'});
    res.json({success:true, data:event});
  } catch(e){ res.status(500).json({success:false, error:e.message}); }
});

app.get('/api/events/stats/am', function(req, res){
  try {
    var data = readJSON('event_submissions.json', {submissions:[]});
    var subs = data.submissions||[];
    var stats = {};
    subs.forEach(function(s){
      if(!stats[s.am]) stats[s.am]={am:s.am,total:0,complianceScores:[],nonCompliant:[]};
      stats[s.am].total++;
      stats[s.am].complianceScores.push(s.compliance.score);
      if(s.compliance.score < 100) stats[s.am].nonCompliant.push({id:s.id,date:s.eventDate,store:s.store,score:s.compliance.score});
    });
    Object.keys(stats).forEach(function(am){
      var sc = stats[am].complianceScores;
      stats[am].avgCompliance = sc.length?Math.round(sc.reduce(function(t,v){return t+v;},0)/sc.length):0;
    });
    res.json({success:true, data:stats});
  } catch(e){ res.status(500).json({success:false, error:e.message}); }
});

var eventConcludeUpload = multer({ dest: 'uploads/events/', limits: { fileSize: 10 * 1024 * 1024 } }).array('images', 4);

app.post('/api/events/:id/conclude', function(req, res){
  eventConcludeUpload(req, res, function(err) {
    if(err) return res.status(400).json({success:false, error:err.message});
    try {
      var data = readJSON('event_submissions.json', {submissions:[]});
      var idx = (data.submissions||[]).findIndex(function(s){return s.id===req.params.id;});
      if(idx===-1) return res.status(404).json({success:false, error:'Not found'});
      var ev = data.submissions[idx];
      var sales = parseFloat(req.body.salesGenerated)||0;
      var newImages = (req.files||[]).map(function(f){return '/uploads/events/'+f.filename;});
      ev.salesGenerated = sales;
      ev.status = 'concluded';
      ev.concludedAt = new Date().toISOString();
      ev.images = (ev.images||[]).concat(newImages).slice(0,4);
      if(req.body.notes) ev.notes = req.body.notes;
      data.submissions[idx] = ev;
      data.lastUpdated = new Date().toISOString();
      writeJSON('event_submissions.json', data);
      res.json({success:true, event:ev});
    } catch(e){ res.status(500).json({success:false, error:e.message}); }
  });
});

// Serve event images
app.use('/uploads/events', require('express').static('uploads/events'));
app.use('/uploads/feed', require('express').static('uploads/feed'));
app.use('/uploads/checklist', require('express').static('uploads/checklist'));



// ── HOME SCORES — MTD Visit Completion + Checklist Quality ───────────
app.get('/api/home-scores', function(req, res){
  try {
    var submissions = readJSON('submissions.json', []);
    var stores = readJSON('stores.json', []);
    var targets = readJSON('audits.json', {});
    var amStores = (targets.am_stores) || {};

    // MTD window: 1st of current month → today
    var now = new Date();
    var monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    // Day schedule rules
    var REMOTE_DAYS = ['monday'];
    var ONSITE_DAYS = ['wednesday','friday','saturday','sunday'];

    // Count expected visits MTD per AM
    function getExpectedMTD(amName) {
      var storeList = amStores[amName] || [];
      var storeCount = storeList.length;
      var expected = 0;
      // Walk each day from month start to today
      for(var d = new Date(monthStart); d <= now; d.setDate(d.getDate()+1)) {
        var dayName = d.toLocaleDateString('en-US',{weekday:'long'}).toLowerCase();
        if(REMOTE_DAYS.indexOf(dayName) >= 0) expected += storeCount;
        else if(ONSITE_DAYS.indexOf(dayName) >= 0) expected += 1;
      }
      return expected;
    }

    // Filter MTD submissions — all valid submissions within the month window
    var mtd = submissions.filter(function(s){
      var d = new Date(s.date || s.submittedAt || 0);
      return d >= monthStart && d <= now && (s.store || s.day);
    });

    // Per-AM MTD stats
    var amMap = {};
    Object.keys(amStores).forEach(function(am){
      amMap[am] = { completed: 0, qualityScores: [], expected: getExpectedMTD(am) };
    });

    mtd.forEach(function(s){
      var am = s.am;
      if(!amMap[am]) amMap[am] = { completed: 0, qualityScores: [], expected: 0 };
      amMap[am].completed++;
      if(s.score !== null && s.score !== undefined) amMap[am].qualityScores.push(s.score);
    });

    // Per-store MTD stats
    var storeMap = {};
    mtd.forEach(function(s){
      var key = s.store;
      if(!storeMap[key]) storeMap[key] = { am: s.am, region: s.region||'', completed: 0, qualityScores: [], days: [] };
      storeMap[key].completed++;
      if(s.score !== null && s.score !== undefined) storeMap[key].qualityScores.push(s.score);
      if(s.day && storeMap[key].days.indexOf(s.day) < 0) storeMap[key].days.push(s.day);
    });

    // Build AM-level summary
    var amSummary = Object.keys(amMap).map(function(am){
      var data = amMap[am];
      var completionPct = data.expected > 0 ? Math.round(data.completed / data.expected * 100) : null;
      var avgQuality = data.qualityScores.length > 0
        ? Math.round(data.qualityScores.reduce(function(t,v){return t+v;},0) / data.qualityScores.length)
        : null;
      var storeList = (amStores[am]||[]).map(function(storeName){
        var short = storeName.replace('TH ','');
        var sd = storeMap[short] || storeMap[storeName];
        return {
          name: storeName,
          completed: sd ? sd.completed : 0,
          avgQuality: sd && sd.qualityScores.length > 0
            ? Math.round(sd.qualityScores.reduce(function(t,v){return t+v;},0)/sd.qualityScores.length)
            : null,
          days: sd ? sd.days : []
        };
      });
      return {
        am: am,
        completed: data.completed,
        expected: data.expected,
        completionPct: completionPct,
        avgQuality: avgQuality,
        stores: storeList
      };
    });

    // Also build flat store list (for backward compat)
    var storeResult = stores.map(function(s){
      var short = s.name.replace('TH ','');
      var data = storeMap[short] || storeMap[s.name];
      var score = data && data.qualityScores.length > 0
        ? Math.round(data.qualityScores.reduce(function(t,v){return t+v;},0)/data.qualityScores.length)
        : null;
      return {
        name: s.name,
        am: s.am || (data ? data.am : ''),
        region: s.region || (data ? data.region : ''),
        score: score,
        completedMTD: data ? data.completed : 0,
        hasData: !!(data && data.completed > 0),
        days: data ? data.days : []
      };
    });

    storeResult.sort(function(a,b){
      if(a.hasData && !b.hasData) return -1;
      if(!a.hasData && b.hasData) return 1;
      return (b.score||0) - (a.score||0);
    });

    res.json({
      success: true,
      data: storeResult,
      amSummary: amSummary,
      asOf: now.toISOString(),
      monthStart: monthStart.toISOString(),
      windowDays: now.getDate()
    });
  } catch(e){ res.status(500).json({ success:false, error:e.message }); }
});

app.use("/uploads/fdu", require("express").static(require("path").join(__dirname,"uploads/fdu")));
app.use("/uploads/donuts",require("express").static(require("path").join(__dirname,"uploads/donuts")));

// ── MONDAY 7AM — WEEKLY HEATMAP TO ALL AMs + CEO + JAHID ──
cron.schedule('0 7 * * 1', function(){
  console.log('[CRON] Weekly heatmap email firing...');
  var now = new Date();
  var lastMonday = new Date(now);
  lastMonday.setDate(now.getDate() - 7);
  lastMonday.setHours(0, 0, 0, 0);
  var lastSunday = new Date(lastMonday);
  lastSunday.setDate(lastMonday.getDate() + 6);
  lastSunday.setHours(23, 59, 59, 999);

  var opts    = { day: 'numeric', month: 'short' };
  var label   = lastMonday.toLocaleDateString('en-IN', opts) + ' – ' + lastSunday.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  var html    = buildWeeklyHeatmap(label, lastMonday, lastSunday);
  var subject = '[Tim Ops] Weekly AM Heatmap — ' + label;

  Object.keys(AM_EMAILS).forEach(function(am) {
    if (!AM_EMAILS[am]) return;
    sendEmail(AM_EMAILS[am], subject, html);
  });
  sendEmail(CEO_EMAIL, subject, html);
  sendEmail(HOD_EMAIL, subject, html);
}, { timezone: 'Asia/Kolkata' });

// ── MONDAY 8AM — WEEKLY NUDGE TO ALL AMs ─────────────────
cron.schedule('0 8 * * 1', function(){
  console.log('[CRON] Monday nudge emails firing...');
  var today = new Date();
  var weekStr = today.toLocaleDateString('en-IN',{day:'numeric',month:'long'});
  
  Object.keys(AM_EMAILS).forEach(function(am){
    if (!AM_EMAILS[am]) return;
    var stores = {
      'Raman':['T3DD','T3DD FC','T1DD'],
      'Harish':['Cyber Hub','Select City','Green Park','Basant Lok','Epicuria','AIPL Golf Course'],
      'Rohit':['Skymark','Vegas Mall','NSP','Punjabi Bagh'],
      'Deepak':['Sunview','Bhupindra Road','Malhar Rd','Sangrur','Bucho'],
      'Kajal':['CP67 Mohali','Elante Mall','Sector 35'],
      'Sandeep Mukharjee':['Lokhandwala','PMC Kurla','FIFC'],
      'TBA':['Balewadi','Viman Nagar','PMC Wakad','FC Road'],
      'Akash Rathod':['HPCL-MPE','NMIAL','NMIAL Arrival','Seawoods'],
      'Jagadeesha':['Koramangala','BIAL','Mall of Asia','HSR Layout'],
      'Shivam':['Inorbit Mall','Hyderabad Arrivals','Lakeshore','Hyderabad Airport']
    }[am] || [];
    
    var storeRows=stores.map(function(s){return eRow(s,'MON','#8E8E93');}).join('');
    var checklistRows=eRow('Monday','Financial & Inventory','#B36200')+eRow('Wednesday','Maintenance Visit','#8E8E93')+eRow('Friday','People & Readiness','#8E8E93')+eRow('Sat/Sun','Weekend Ops','#8E8E93');
    var body='<div style="font-size:18px;font-weight:700;color:#1C1C1E;margin-bottom:12px;">Good morning, '+am+' ☕</div>'+
      '<p style="font-size:14px;line-height:1.6;color:#3C3C43;margin-bottom:16px;">New week, fresh start. Monday checklist covers all stores — due by Monday midnight.</p>'+
      eCard('Your Stores This Week',storeRows)+
      eCard('This Week Schedule',checklistRows)+
      eBtn('Open Tasks &rarr;','https://staging.opsaihub.in/tasks.html');
    var html=eWrap(body,'Weekly Reminder','Weekly Checklist Reminder &mdash; Week of '+weekStr);
    
    sendEmail(AM_EMAILS[am], '[Tim Ops] Week of '+weekStr+' &mdash; Checklists Ready', html);
  });
}, { timezone: 'Asia/Kolkata' });

// ── MONDAY 9AM — WEEKLY OPS REPORT TO CEO ────────────────
cron.schedule('0 9 * * 1', function(){
  var now = new Date();
  // Last week Mon–Sun
  var dayOfWeek = now.getDay(); // 1 = Monday
  var lastMonday = new Date(now);
  lastMonday.setDate(now.getDate() - 7);
  lastMonday.setHours(0, 0, 0, 0);
  var lastSunday = new Date(lastMonday);
  lastSunday.setDate(lastMonday.getDate() + 6);
  lastSunday.setHours(23, 59, 59, 999);

  var opts = { day: 'numeric', month: 'short' };
  var label = lastMonday.toLocaleDateString('en-IN', opts) + ' – ' + lastSunday.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  console.log('[CRON] Weekly CEO report firing for', label);
  var html = buildCeoReport('Week: ' + label, lastMonday, lastSunday);
  sendEmail(
    CEO_EMAIL,
    '[Tim\'s Ops Connect] Weekly Ops Report — ' + label,
    html,
    function() {}
  );
  sendEmail(
    HOD_EMAIL,
    '[Tim\'s Ops Connect] Weekly Ops Report — ' + label,
    html,
    function() {}
  );
}, { timezone: 'Asia/Kolkata' });

// ── DAILY 8AM — CLAUDE BRIEFING TO JAHID ─────────────────
cron.schedule('0 8 * * *', function(){
  console.log('[CRON] Daily briefing generating...');
  generateBriefing(function(err, briefing){
    var today = new Date();
    var dateStr = today.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
    var subs = readJSON('submissions.json', []);
    var todaySubs = subs.filter(function(s){
      return new Date(s.submittedAt||s.timestamp||0).toDateString()===today.toDateString();
    });
    
    var html = emailStyle()+'<div class="wrap">'+
      '<div class="hdr"><div class="hdr-logo">Tim Ops Connect</div><div class="hdr-sub">Daily Briefing &mdash; '+dateStr+'</div></div>'+
      '<div class="body">'+
      '<div class="greeting">Good morning, Jahid ☕</div>'+
      '<div class="card" style="background:linear-gradient(135deg,#0D1B2A,#1A0D2E);color:#fff;">'+
      '<div class="card-ttl" style="color:rgba(255,255,255,0.5);">AI Ops Briefing</div>'+
      '<p style="font-size:14px;line-height:1.7;color:rgba(255,255,255,0.9);">'+briefing.split('\n').join('<br>')+'</p></div>'+
      '<div class="card"><div class="card-ttl">Submissions Today</div>'+
      '<div class="card-val">'+(todaySubs.length||0)+'</div>'+
      '<p style="font-size:12px;color:#8E8E93;margin-top:4px;">received so far</p></div>'+
      '<div class="card"><div class="card-ttl">System Status</div>'+
      '<div style="font-size:13px;color:#1B7A3A;font-weight:700;">All systems operational</div>'+
      '<div style="font-size:11px;color:#8E8E93;margin-top:4px;">Staging: staging.opsaihub.in</div></div>'+
      '<a href="https://staging.opsaihub.in/hod.html" class="btn">Open HOD Dashboard &rarr;</a>'+
      '</div>'+
      '<div class="footer">Tim Hortons India &middot; OpsAIHub &middot; Daily automated briefing</div></div>';
    
    sendEmail(HOD_EMAIL, '[Tim Ops] Daily Briefing &mdash; '+dateStr, html);
  });
}, { timezone: 'Asia/Kolkata' });

// ── FRIDAY 6PM — CHASE NON-SUBMITTERS ────────────────────
cron.schedule('0 18 * * 5', function(){
  console.log('[CRON] Friday chase emails checking...');
  var subs = readJSON('submissions.json', []);
  var thisWeekStart = new Date();
  thisWeekStart.setDate(thisWeekStart.getDate() - thisWeekStart.getDay() + 1);
  thisWeekStart.setHours(0,0,0,0);
  
  var submitted = {};
  subs.forEach(function(s){
    var d = new Date(s.submittedAt||s.timestamp||0);
    if(d >= thisWeekStart && s.am) submitted[s.am] = true;
  });
  
  Object.keys(AM_EMAILS).forEach(function(am){
    if (!AM_EMAILS[am]) return;
    if(!submitted[am]){
      var html = emailStyle()+'<div class="wrap">'+
        '<div class="hdr" style="background:linear-gradient(135deg,#B36200,#7A4200);">'+
        '<div class="hdr-logo">Tim Ops Connect</div><div class="hdr-sub">Checklist Reminder &mdash; Action Required</div></div>'+
        '<div class="body">'+
        '<div class="greeting">Hi '+am+',</div>'+
        '<div class="card" style="border:2px solid #FF9500;">'+
        '<div class="card-ttl" style="color:#B36200;">Pending This Week</div>'+
        '<p style="font-size:14px;color:#1C1C1E;line-height:1.6;">Your weekly checklist submissions are pending. Please complete and submit before <strong>end of day Sunday.</strong></p>'+
        '<p style="font-size:13px;color:#8E8E93;">Late submissions are accepted but flagged. Consistent late submissions impact your performance score.</p>'+
        '</div>'+
        '<a href="https://staging.opsaihub.in/tasks.html" class="btn" style="background:#FF9500;">Complete Checklist Now &rarr;</a>'+
        '</div>'+
        '<div class="footer">Tim Hortons India &middot; OpsAIHub &middot; Automated reminder</div></div>';
      
      sendEmail(AM_EMAILS[am], '[Tim Ops] Action Required: Checklist Pending This Week', html);
    }
  });
}, { timezone: 'Asia/Kolkata' });

// ── SUNDAY 9AM — PERSONAL WEEKLY SUMMARY TO EACH AM ──────
cron.schedule('0 9 * * 0', function(){
  console.log('[CRON] Sunday summaries firing...');
  var subs = readJSON('submissions.json', []);
  var kpi = readJSON('sales_summary.json', {});
  var weekStart = new Date();
  weekStart.setDate(weekStart.getDate() - 6);
  weekStart.setHours(0,0,0,0);
  var weekStr = weekStart.toLocaleDateString('en-IN',{day:'numeric',month:'short'})+' - '+new Date().toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
  
  Object.keys(AM_EMAILS).forEach(function(am){
    if (!AM_EMAILS[am]) return;
    var amSubs = subs.filter(function(s){ return s.am===am && new Date(s.submittedAt||s.timestamp||0)>=weekStart; });
    var days = ['Monday','Wednesday','Friday','Saturday','Sunday'];
    
    var html = emailStyle()+'<div class="wrap">'+
      '<div class="hdr"><div class="hdr-logo">Tim Ops Connect</div><div class="hdr-sub">Your Week in Review &mdash; '+weekStr+'</div></div>'+
      '<div class="body">'+
      '<div class="greeting">Good morning, '+am+' ☕</div>'+
      '<p style="font-size:14px;color:#3C3C43;line-height:1.6;">Here is your weekly summary. Great work staying on top of your stores.</p>'+
      '<div class="card"><div class="card-ttl">Submissions This Week</div>'+
      '<div class="card-val '+( amSubs.length>=4?'green':'amber')+'">'+amSubs.length+' / 6</div>'+
      '<p style="font-size:12px;color:#8E8E93;margin-top:4px;">checklists submitted</p></div>'+
      '<div class="card"><div class="card-ttl">Week Summary</div>'+
      days.map(function(day){
        var hasSub = amSubs.some(function(s){ return (s.day||'').toLowerCase()===day.toLowerCase(); });
        return '<div class="row"><span style="font-size:13px;">'+day+'</span><span style="font-size:12px;font-weight:700;color:'+(hasSub?'#1B7A3A':'#C8102E')+'">'+(hasSub?'Submitted':'Pending')+'</span></div>';
      }).join('')+
      '</div>'+
      '<div class="card" style="background:linear-gradient(135deg,#C8102E,#8B0B1F);"><div class="card-ttl" style="color:rgba(255,255,255,0.6);">New Week Starts Tomorrow</div>'+
      '<p style="font-size:14px;color:#fff;line-height:1.6;">Monday checklist is due by Tuesday midnight. Start the week strong.</p></div>'+
      '<a href="https://staging.opsaihub.in" class="btn">Open OpsAIHub &rarr;</a>'+
      '</div>'+
      '<div class="footer">Tim Hortons India &middot; OpsAIHub &middot; Weekly automated summary</div></div>';
    
    sendEmail(AM_EMAILS[am], '[Tim Ops] Your Week in Review &mdash; '+weekStr, html);
  });
}, { timezone: 'Asia/Kolkata' });

// ── 1ST OF MONTH — COVERAGE RESET + REPORT ───────────────
cron.schedule('0 7 1 * *', function(){
  console.log('[CRON] Monthly reset firing...');
  var now = new Date();
  var month = now.toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  
  // Reset coverage
  var coverage = readJSON('coverage.json', {});
  coverage.lastReset = now.toISOString();
  coverage.currentMonth = now.getMonth()+1+'-'+now.getFullYear();
  writeJSON('coverage.json', coverage);
  
  // Email Jahid
  var html = emailStyle()+'<div class="wrap">'+
    '<div class="hdr"><div class="hdr-logo">Tim Ops Connect</div><div class="hdr-sub">Monthly Reset &mdash; '+month+'</div></div>'+
    '<div class="body">'+
    '<div class="greeting">New month, Jahid ☕</div>'+
    '<div class="card"><div class="card-ttl">Monthly Reset Complete</div>'+
    '<p style="font-size:14px;color:#1C1C1E;line-height:1.6;">Coverage counters have been reset for all 44 stores. All Area Managers start fresh for '+month+'.</p></div>'+
    '<div class="card"><div class="card-ttl">This Month Targets</div>'+
    '<div class="row"><span style="font-size:13px;">Store Visits</span><span style="font-size:12px;font-weight:700;color:#007AFF;">Every store once</span></div>'+
    '<div class="row"><span style="font-size:13px;">Mon/Tue Submissions</span><span style="font-size:12px;font-weight:700;color:#007AFF;">4 weeks x all stores</span></div>'+
    '<div class="row"><span style="font-size:13px;">Assessment</span><span style="font-size:12px;font-weight:700;color:#007AFF;">1 module per AM</span></div>'+
    '</div>'+
    '<a href="https://staging.opsaihub.in/hod.html" class="btn">View HOD Dashboard &rarr;</a>'+
    '</div>'+
    '<div class="footer">Tim Hortons India &middot; OpsAIHub &middot; Monthly automated report</div></div>';
  
  sendEmail(HOD_EMAIL, '[Tim Ops] Monthly Reset Complete &mdash; '+month, html);

  // ── Monthly CEO ops report (covers the month that just ended) ──
  var lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  var lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
  var monthLabel = lastMonth.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  console.log('[CRON] Monthly CEO report firing for', monthLabel);
  var ceoHtml = buildCeoReport(monthLabel, lastMonth, lastMonthEnd);
  sendEmail(
    CEO_EMAIL,
    '[Tim\'s Ops Connect] Monthly Ops Report — ' + monthLabel,
    ceoHtml,
    function() {}
  );
  sendEmail(
    HOD_EMAIL,
    '[Tim\'s Ops Connect] Monthly Ops Report — ' + monthLabel,
    ceoHtml,
    function() {}
  );
}, { timezone: 'Asia/Kolkata' });

// ── SELF-HEALING MONITOR — EVERY 15 MINS ─────────────────
var lastDownAlert = null;
cron.schedule('*/15 * * * *', function(){
  var http = require('http');
  http.get('http://localhost:'+PORT+'/health', function(res){
    if(res.statusCode !== 200){
      var now = new Date();
      if(!lastDownAlert || (now-lastDownAlert) > 3600000){
        lastDownAlert = now;
        sendEmail(HOD_EMAIL, '[ALERT] OpsAIHub DOWN - '+res.statusCode,
          emailStyle()+'<div class="wrap"><div class="hdr" style="background:linear-gradient(135deg,#FF3B30,#C8102E);"><div class="hdr-logo">OpsAIHub Alert</div></div>'+
          '<div class="body"><div class="greeting" style="color:#C8102E;">Site Health Alert</div>'+
          '<div class="card" style="border:2px solid #FF3B30;"><div class="card-ttl" style="color:#C8102E;">Status Code: '+res.statusCode+'</div>'+
          '<p style="font-size:14px;">OpsAIHub staging returned a non-200 response at '+now.toLocaleString('en-IN')+'. PM2 auto-restart should recover this automatically.</p></div>'+
          '<div class="card"><div class="card-ttl">Manual Recovery</div>'+
          '<p style="font-family:monospace;font-size:12px;background:#F5F5F7;padding:8px;border-radius:6px;">pm2 restart th-staging</p></div>'+
          '</div><div class="footer">OpsAIHub Self-Healing Monitor</div></div>');
      }
    } else {
      lastDownAlert = null;
    }
  }).on('error', function(e){
    var now = new Date();
    if(!lastDownAlert || (now-lastDownAlert) > 3600000){
      lastDownAlert = now;
      sendEmail(HOD_EMAIL, '[ALERT] OpsAIHub UNREACHABLE',
        emailStyle()+'<div class="wrap"><div class="hdr" style="background:linear-gradient(135deg,#FF3B30,#C8102E);"><div class="hdr-logo">OpsAIHub Alert</div></div>'+
        '<div class="body"><div class="greeting" style="color:#C8102E;">Site Unreachable</div>'+
        '<div class="card" style="border:2px solid #FF3B30;">'+
        '<p style="font-size:14px;">Cannot reach OpsAIHub at '+now.toLocaleString('en-IN')+'. Error: '+e.message+'</p>'+
        '<p style="font-family:monospace;font-size:12px;background:#F5F5F7;padding:8px;border-radius:6px;margin-top:8px;">pm2 restart th-staging</p></div>'+
        '</div><div class="footer">OpsAIHub Self-Healing Monitor</div></div>');
    }
  });
});

// ── DAILY 11PM — DATA BACKUP ─────────────────────────────
cron.schedule('0 23 * * *', function(){
  var exec = require('child_process').exec;
  var date = new Date().toISOString().split('T')[0];
  var backupDir = process.env.HOME+'/backups/'+date;
  exec('mkdir -p '+backupDir+' && cp -r '+__dirname+'/data/* '+backupDir+'/', function(err){
    if(err) console.log('[BACKUP] Error:', err.message);
    else console.log('[BACKUP] Data backed up to', backupDir);
    // Keep last 30 days
    exec('ls '+process.env.HOME+'/backups/ | sort | head -n -30 | xargs -I{} rm -rf '+process.env.HOME+'/backups/{}', function(){});
  });
});

// ── TEST EMAIL ROUTE ──────────────────────────────────────
app.post('/api/test-email', function(req, res){
  sendEmail(HOD_EMAIL, '[Test] OpsAIHub Email Working',
    emailStyle()+'<div class="wrap"><div class="hdr"><div class="hdr-logo">Tim Ops Connect</div></div>'+
    '<div class="body"><div class="greeting">Test email ☕</div>'+
    '<p style="font-size:14px;color:#3C3C43;">Email system is working correctly. All automated emails will be sent from this address.</p>'+
    '<div class="card"><div class="card-ttl">Scheduled Emails</div>'+
    '<div class="row"><span>Monday 8am</span><span style="color:#007AFF;">AM weekly nudge</span></div>'+
    '<div class="row"><span>Daily 8am</span><span style="color:#007AFF;">Jahid briefing</span></div>'+
    '<div class="row"><span>Friday 6pm</span><span style="color:#007AFF;">Chase non-submitters</span></div>'+
    '<div class="row"><span>Sunday 9am</span><span style="color:#007AFF;">AM weekly summary</span></div>'+
    '<div class="row"><span>Every 15 mins</span><span style="color:#007AFF;">Self-healing monitor</span></div>'+
    '<div class="row"><span>Daily 11pm</span><span style="color:#007AFF;">Data backup</span></div>'+
    '</div></div><div class="footer">OpsAIHub &middot; Step 12 Complete</div></div>',
    function(err){ res.json({ success:!err, error:err?err.message:null }); }
  );
});

// ── FRIDAY 9AM — WEEKLY LEADERBOARD POST ─────────────────
cron.schedule('0 9 * * 5', function() {
  console.log('[CRON] Friday leaderboard firing...');
  postWeeklyLeaderboard();
}, { timezone: 'Asia/Kolkata' });

console.log('[CRON] All automation scheduled — 9 jobs active');

// ── AI ACADEMY CERTIFICATE CRON — 1st of month 7:30 AM IST ──────────────────
cron.schedule('30 7 1 * *', function(){
  var now = new Date();
  var lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  var monthKey = lastMonthDate.getFullYear() + '-' + String(lastMonthDate.getMonth()+1).padStart(2,'0');
  var monthLabel = lastMonthDate.toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  var academy = readJSON('ai_academy.json', {});

  Object.keys(AM_EMAILS).forEach(function(am) {
    var email = AM_EMAILS[am];
    if (!email) return;
    var amData = academy[am] || {};
    var cert = checkMonthlyAICompletion(amData, monthKey);
    if (!cert.achieved) return;
    // Mark certificate issued
    if (!amData.certificates) amData.certificates = [];
    if (amData.certificates.indexOf(monthKey) >= 0) return; // already sent
    amData.certificates.push(monthKey);
    academy[am] = amData;
    // Send certificate email
    var html = buildAICertificateEmail(am, monthLabel, cert.watchedCount, cert.bestScore);
    sendEmail(email, '[TH AI Academy] Your ' + monthLabel + ' Excellence Certificate 🎓', html);
    sendEmail(HOD_EMAIL, '[TH AI Academy] ' + am + ' earned AI Certificate for ' + monthLabel, html);
  });
  writeJSON('ai_academy.json', academy);
  console.log('[CRON] AI Academy certificate emails sent for', monthKey);
}, { timezone: 'Asia/Kolkata' });

// ── AI Academy: bi-daily 9AM reminder for AMs with incomplete learning ────────
cron.schedule('0 9 */2 * *', function() {
  var academy = readJSON('ai_academy.json', {});
  var wk = aiWeekKey();
  Object.keys(AM_EMAILS).forEach(function(am) {
    var email = AM_EMAILS[am];
    if (!email) return;
    var amData = academy[am] || {};
    var weekData = (amData.weeks||{})[wk] || {};
    var watched = weekData.watched || [];
    if (weekData.quizPassed) return; // already passed this week — no reminder
    var missed = AI_CORE_VIDEO_TITLES.filter(function(v){ return watched.indexOf(v.key) < 0; });
    if (missed.length === 0) return; // watched all, just needs to take quiz
    var watchedPct = Math.round((AI_CORE_VIDEO_TITLES.length - missed.length) / AI_CORE_VIDEO_TITLES.length * 100);
    var missedHtml = missed.map(function(v){
      return '<li style="margin-bottom:8px;font-size:14px;color:#1C1C1E;">📹 ' + v.title + '</li>';
    }).join('');
    var html = emailStyle() + '<div class="wrap">' +
      '<div class="hdr"><div class="hdr-logo">TH AI Academy</div><div class="hdr-sub">Your Weekly AI Learning Reminder</div></div>' +
      '<div class="body">' +
      '<div class="greeting">Hey ' + am + '! 🤖</div>' +
      '<p style="font-size:15px;color:#1C1C1E;line-height:1.6;">Your AI learning journey is <strong>' + watchedPct + '% complete</strong> this week — ' + missed.length + ' video' + (missed.length!==1?'s':'') + ' still to go:</p>' +
      '<div style="background:#F5F5FA;border-radius:12px;padding:16px;margin:16px 0;">' +
        '<ul style="list-style:none;padding:0;margin:0;">' + missedHtml + '</ul>' +
      '</div>' +
      '<p style="font-size:13px;color:#6B7280;line-height:1.6;">Watch all 5 core videos to unlock the weekly quiz. Score 80%+ to earn recognition on the team social feed and build towards your monthly AI Excellence Certificate! 🏆</p>' +
      '<a href="https://opsaihub.in/tasks.html" class="btn">Continue AI Academy →</a>' +
      '</div>' +
      '<div class="footer">Tim Hortons India · TH AI Academy · ' + wk + '</div></div>';
    sendEmail(email, '[TH AI Academy] ' + missed.length + ' video' + (missed.length!==1?'s':'') + ' left this week — keep going! 🎯', html);
  });
  console.log('[CRON] AI Academy bi-daily reminders processed for', wk);
}, { timezone: 'Asia/Kolkata' });

function checkMonthlyAICompletion(amData, monthKey) {
  var weeks = amData.weeks || {};
  var watched = new Set();
  var bestScore = 0;
  var weeksPassed = 0;
  Object.keys(weeks).forEach(function(wk) {
    if (wk.startsWith(monthKey.slice(0,4))) { // same year
      var wNum = parseInt(wk.split('-W')[1]);
      var refDate = weekNumberToDate(parseInt(monthKey.slice(0,4)), wNum);
      var refMonth = refDate.getFullYear() + '-' + String(refDate.getMonth()+1).padStart(2,'0');
      if (refMonth !== monthKey) return;
    } else { return; }
    var w = weeks[wk];
    (w.watched || []).forEach(function(v){ watched.add(v); });
    if (w.quizScore && w.quizScore > bestScore) bestScore = w.quizScore;
    if (w.quizPassed) weeksPassed++;
  });
  var watchedCount = watched.size;
  var achieved = watchedCount >= 5 && bestScore >= 80;
  return { achieved: achieved, watchedCount: watchedCount, bestScore: bestScore, weeksPassed: weeksPassed };
}

function weekNumberToDate(year, week) {
  var simple = new Date(year, 0, 1 + (week - 1) * 7);
  var dow = simple.getDay();
  var ISOweekStart = simple;
  if (dow <= 4) ISOweekStart.setDate(simple.getDate() - simple.getDay() + 1);
  else ISOweekStart.setDate(simple.getDate() + 8 - simple.getDay());
  return ISOweekStart;
}

function buildAICertificateEmail(am, monthLabel, watchedCount, bestScore) {
  return emailStyle() + '<div class="wrap">' +
    '<div class="hdr"><div class="hdr-logo">TH AI Academy</div><div class="hdr-sub">Monthly Excellence Certificate &mdash; ' + monthLabel + '</div></div>' +
    '<div class="body">' +
    '<div class="greeting">Congratulations, ' + am + '! 🎓</div>' +
    '<div style="background:linear-gradient(135deg,#0D0D2B,#1A1040);border-radius:16px;padding:28px 20px;text-align:center;margin-bottom:20px;">' +
      '<div style="font-size:48px;margin-bottom:12px;">🏆</div>' +
      '<div style="font-size:11px;font-weight:700;color:rgba(165,180,252,0.8);text-transform:uppercase;letter-spacing:2px;margin-bottom:8px;">TH AI Academy</div>' +
      '<div style="font-size:22px;font-weight:800;color:#fff;margin-bottom:4px;">Monthly Excellence Certificate</div>' +
      '<div style="font-size:15px;color:rgba(255,255,255,0.6);margin-bottom:20px;">' + monthLabel + '</div>' +
      '<div style="font-size:28px;font-weight:800;color:#a5b4fc;margin-bottom:4px;">' + am + '</div>' +
      '<div style="font-size:13px;color:rgba(255,255,255,0.5);">Area Manager, Tim Hortons India</div>' +
      '<div style="display:flex;gap:16px;justify-content:center;margin-top:20px;">' +
        '<div style="background:rgba(99,102,241,0.2);border-radius:12px;padding:12px 16px;text-align:center;">' +
          '<div style="font-size:24px;font-weight:800;color:#a5b4fc;">' + watchedCount + '/5</div>' +
          '<div style="font-size:11px;color:rgba(255,255,255,0.5);">Videos Watched</div>' +
        '</div>' +
        '<div style="background:rgba(99,102,241,0.2);border-radius:12px;padding:12px 16px;text-align:center;">' +
          '<div style="font-size:24px;font-weight:800;color:#a5b4fc;">' + bestScore + '%</div>' +
          '<div style="font-size:11px;color:rgba(255,255,255,0.5);">Best Quiz Score</div>' +
        '</div>' +
      '</div>' +
    '</div>' +
    '<div class="card"><div class="card-ttl">What You Achieved</div>' +
    '<p style="font-size:14px;color:#1C1C1E;line-height:1.6;">You completed the TH AI Academy for <strong>' + monthLabel + '</strong> — watching ' + watchedCount + ' AI learning videos and scoring <strong>' + bestScore + '%</strong> on the knowledge quiz. You are now among the most AI-literate managers in Tim Hortons India.</p>' +
    '</div>' +
    '<a href="https://opsaihub.in/tasks.html" class="btn">Open AI Academy &rarr;</a>' +
    '</div>' +
    '<div class="footer">Tim Hortons India &middot; TH AI Academy &middot; ' + monthLabel + ' Certificate</div></div>';
}

// ════════════════════════════════════════════════════════════




// ── AI ACADEMY ROUTES ────────────────────────────────────
var AI_CORE_VIDEO_TITLES = [
  { key:'v0', title:'Ultimate Claude AI Guide 2026 — How to Use Claude for Beginners' },
  { key:'v1', title:'AI Masterclass: ChatGPT, Gemini, Claude & Perplexity for Beginners' },
  { key:'v2', title:"Don't Prompt ChatGPT, Gemini or Claude Wrong in 2026 — Try This Instead" },
  { key:'v3', title:'Google NotebookLM — How to Master It in 2026 (Free Course)' },
  { key:'v4', title:'ChatGPT vs Gemini vs Claude: Brutal Head-to-Head Test' },
  { key:'v5', title:'ChatGPT vs Claude vs Gemini: Best AI for Each Use Case' }
];

function aiWeekKey(date) {
  var d = date || new Date();
  var start = new Date(d.getFullYear(), 0, 1);
  var week = Math.ceil(((d - start) / 86400000 + start.getDay() + 1) / 7);
  return d.getFullYear() + '-W' + String(week).padStart(2,'0');
}

app.get('/api/ai-academy/leaderboard', function(req,res){
  try {
    var data = readJSON('ai_academy.json', {});
    var results = Object.keys(AM_EMAILS).filter(function(am){ return am !== 'TBA'; }).map(function(am) {
      var amData = data[am] || { weeks:{}, certificates:[] };
      var weeks = amData.weeks || {};
      var allWatched = {}, weeksPassed = 0, bestScore = 0;
      Object.keys(weeks).forEach(function(wk) {
        var wd = weeks[wk];
        (wd.watched||[]).forEach(function(v){ if(v.charAt(0)==='v') allWatched[v]=1; });
        if (wd.quizPassed) weeksPassed++;
        if ((wd.quizScore||0) > bestScore) bestScore = wd.quizScore||0;
      });
      var certs = (amData.certificates||[]).length;
      var uniqueWatched = Object.keys(allWatched).length;
      var score = weeksPassed * 30 + uniqueWatched * 5 + Math.round(bestScore * 0.5) + certs * 50;
      return { am:am, videosWatched:uniqueWatched, weeksPassed:weeksPassed, bestScore:bestScore, certificates:certs, score:score };
    });
    results.sort(function(a,b){ return b.score - a.score; });
    res.json({ success:true, leaderboard:results, weekKey:aiWeekKey() });
  } catch(e){ res.status(500).json({success:false,error:e.message}); }
});

app.get('/api/ai-academy/:am', function(req,res){
  try {
    var data = readJSON('ai_academy.json', {});
    var am = decodeURIComponent(req.params.am);
    var amData = data[am] || { weeks:{}, certificates:[] };
    // Compute monthly status for current month
    var now = new Date();
    var monthKey = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0');
    var monthly = checkMonthlyAICompletion(amData, monthKey);
    // Compute last month status (for certificate flash)
    var lastMonthDate = new Date(now.getFullYear(), now.getMonth()-1, 1);
    var lastMonthKey = lastMonthDate.getFullYear() + '-' + String(lastMonthDate.getMonth()+1).padStart(2,'0');
    var lastMonthly = checkMonthlyAICompletion(amData, lastMonthKey);
    var lastMonthLabel = lastMonthDate.toLocaleDateString('en-IN',{month:'long',year:'numeric'});
    var hasPendingCert = lastMonthly.achieved && (amData.certificates||[]).indexOf(lastMonthKey) < 0;
    res.json({ success:true, data: amData, weekKey: aiWeekKey(), monthKey: monthKey,
      monthlyStatus: monthly, hasPendingCert: hasPendingCert,
      pendingCertMonth: hasPendingCert ? lastMonthKey : null,
      pendingCertLabel: hasPendingCert ? lastMonthLabel : null,
      pendingCertStats: hasPendingCert ? lastMonthly : null });
  } catch(e){ res.status(500).json({success:false,error:e.message}); }
});

app.post('/api/ai-academy/watch', function(req,res){
  try {
    var data = readJSON('ai_academy.json', {});
    var am = req.body.am, videoKey = req.body.videoKey;
    if (!am || !videoKey) return res.status(400).json({success:false,error:'Missing am or videoKey'});
    var wk = aiWeekKey();
    if (!data[am]) data[am] = { weeks:{}, certificates:[] };
    if (!data[am].weeks[wk]) data[am].weeks[wk] = { watched:[], quizScore:null, quizPassed:false };
    if (data[am].weeks[wk].watched.indexOf(videoKey) < 0) {
      data[am].weeks[wk].watched.push(videoKey);
    }
    writeJSON('ai_academy.json', data);
    var watchedCount = data[am].weeks[wk].watched.length;
    res.json({ success:true, watchedCount: watchedCount, quizUnlocked: watchedCount >= 5 });
  } catch(e){ res.status(500).json({success:false,error:e.message}); }
});

app.post('/api/ai-academy/quiz', function(req,res){
  try {
    var data = readJSON('ai_academy.json', {});
    var am = req.body.am, score = parseInt(req.body.score)||0;
    if (!am) return res.status(400).json({success:false,error:'Missing am'});
    var wk = aiWeekKey();
    if (!data[am]) data[am] = { weeks:{}, certificates:[] };
    if (!data[am].weeks[wk]) data[am].weeks[wk] = { watched:[], quizScore:null, quizPassed:false };
    var wasAlreadyPassed = data[am].weeks[wk].quizPassed;
    data[am].weeks[wk].quizScore = score;
    data[am].weeks[wk].quizPassed = score >= 80;
    data[am].weeks[wk].quizDate = new Date().toISOString().slice(0,10);
    writeJSON('ai_academy.json', data);
    // Check monthly
    var now = new Date();
    var monthKey = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0');
    var monthly = checkMonthlyAICompletion(data[am], monthKey);
    // Auto-post to social feed on first weekly pass
    if (score >= 80 && !wasAlreadyPassed) {
      var _amSnap = am, _scoreSnap = score, _wkSnap = wk, _dataSnap = data;
      setImmediate(function() {
        try {
          var posts = readJSON('posts.json', []);
          var watchedCount = (_dataSnap[_amSnap].weeks[_wkSnap].watched||[]).filter(function(v){return v.charAt(0)==='v';}).length;
          var certs = (_dataSnap[_amSnap].certificates||[]).length;
          var caption = '🤖 ' + _amSnap + ' just passed this week\'s AI Academy quiz with ' + _scoreSnap + '%! ' +
            'Watched ' + watchedCount + '/5 core videos this week and levelling up on AI skills. 🎯' +
            (certs > 0 ? ' 🏆 ' + certs + ' monthly certificate' + (certs > 1 ? 's' : '') + ' earned!' : '') +
            ' #AIAcademy #THIndia #LearningNeverStops ☕';
          posts.unshift({
            id: Date.now().toString() + '_aipass',
            author: 'Jahid', category: 'learning', store: 'TH AI Academy',
            taggedPerson: _amSnap, caption: caption,
            isAutoPost: true, isAIPost: true,
            reactions: { '❤️':0, '🔥':0, '👏':0, '⭐':0, '☕':0 },
            comments: [], createdAt: new Date().toISOString(), timeAgo: 'Just now'
          });
          writeJSON('posts.json', posts);
        } catch(pe) { console.error('AI quiz social post error:', pe.message); }
      });
    }
    res.json({ success:true, passed: score >= 80, score: score, monthly: monthly });
  } catch(e){ res.status(500).json({success:false,error:e.message}); }
});

app.post('/api/ai-academy/challenge', function(req,res){
  try {
    var data = readJSON('ai_academy.json', {});
    var am = req.body.am, wk = req.body.weekKey || aiWeekKey();
    if (!am) return res.status(400).json({success:false,error:'Missing am'});
    if (!data[am]) data[am] = { weeks:{}, certificates:[] };
    if (!data[am].weeks[wk]) data[am].weeks[wk] = { watched:[], quizScore:null, quizPassed:false };
    data[am].weeks[wk].challengeDone = true;
    writeJSON('ai_academy.json', data);
    res.json({ success:true });
  } catch(e){ res.status(500).json({success:false,error:e.message}); }
});

app.post('/api/ai-academy/ack-cert', function(req,res){
  try {
    var data = readJSON('ai_academy.json', {});
    var am = req.body.am, monthKey = req.body.monthKey;
    if (!data[am]) data[am] = { weeks:{}, certificates:[] };
    if (!data[am].certificates) data[am].certificates = [];
    if (data[am].certificates.indexOf(monthKey) < 0) data[am].certificates.push(monthKey);
    writeJSON('ai_academy.json', data);
    res.json({ success:true });
  } catch(e){ res.status(500).json({success:false,error:e.message}); }
});

// ── MTD SALES ROUTES ─────────────────────────────────────
app.get('/api/mtd/summary',function(req,res){
  try{
    var kpi=readJSON('kpi_mar2026.json',{});
    var stores=kpi.stores||{};
    var names=Object.keys(stores);
    if(names.length===0) return res.json({success:true,data:{totalMTDSales:0,avgADT:0,avgAPC:0,storeCount:0}});
    var totalSales=names.reduce(function(sum,s){return sum+(stores[s].ads||0)*(kpi.days||25);},0);
    var avgADT=Math.round(names.reduce(function(sum,s){return sum+(stores[s].adt||0);},0)/names.length);
    var avgAPC=Math.round(names.reduce(function(sum,s){return sum+(stores[s].apc||0);},0)/names.length);
    res.json({success:true,data:{totalMTDSales:totalSales,avgADT:avgADT,avgAPC:avgAPC,storeCount:names.length,days:kpi.days||25,indiaADT:kpi.india_adt||avgADT,indiaAPC:kpi.india_apc||avgAPC}});
  }catch(e){console.error('MTD summary error:',e.message);res.status(500).json({success:false,error:e.message});}
});
app.get('/api/mtd/stores',function(req,res){
  try{
    var kpi=readJSON('kpi_mar2026.json',{});
    var master=readJSON('stores.json',[]);
    var kd=kpi.stores||{};
    var result=master.map(function(s){
      var d=kd[s.name]||kd['TH '+s.name]||{};
      return {storeCode:s.id,storeName:s.name,am:s.am,region:s.region,mtdSales:(d.ads||0)*(kpi.days||25),ads:d.ads||0,adt:d.adt||0,apc:d.apc||0,donut:d.donut||0,timbit:d.timbit||0,water:d.water||0};
    });
    res.json({success:true,data:result});
  }catch(e){res.status(500).json({success:false,error:e.message});}
});
app.get('/api/mtd/am/:amName',function(req,res){
  try{
    var kpi=readJSON('kpi_mar2026.json',{});
    var master=readJSON('stores.json',[]);
    var kd=kpi.stores||{};
    var amStores=master.filter(function(s){return s.am&&s.am.toLowerCase()===decodeURIComponent(req.params.amName).toLowerCase();});
    if(!amStores.length) return res.status(404).json({success:false,error:'AM not found'});
    var sd=amStores.map(function(s){var d=kd[s.name]||kd['TH '+s.name]||{};return {storeName:s.name,ads:d.ads||0,adt:d.adt||0,apc:d.apc||0,mtdSales:(d.ads||0)*(kpi.days||25)};});
    var totalSales=sd.reduce(function(sum,s){return sum+s.mtdSales;},0);
    var avgADT=Math.round(sd.reduce(function(sum,s){return sum+s.adt;},0)/Math.max(sd.length,1));
    var avgAT=Math.round(sd.reduce(function(sum,s){return sum+s.apc;},0)/Math.max(sd.length,1));
    res.json({success:true,data:{am:req.params.amName,totalMTDSales:totalSales,avgADT:avgADT,avgAT:avgAT,storeCount:sd.length,stores:sd}});
  }catch(e){res.status(500).json({success:false,error:e.message});}
});
app.get('/api/mtd/am-summary',function(req,res){
  try{
    var kpi=readJSON('kpi_mar2026.json',{});
    var master=readJSON('stores.json',[]);
    var kd=kpi.stores||{};
    var amMap={};
    master.forEach(function(s){
      if(!s.am) return;
      if(!amMap[s.am]) amMap[s.am]={am:s.am,region:s.region||'',totalMTDSales:0,storeCount:0,adts:[],apcs:[]};
      var d=kd[s.name]||kd['TH '+s.name]||{};
      amMap[s.am].totalMTDSales+=(d.ads||0)*(kpi.days||25);
      amMap[s.am].adts.push(d.adt||0);
      amMap[s.am].apcs.push(d.apc||0);
      amMap[s.am].storeCount++;
    });
    var result=Object.values(amMap).map(function(a){
      a.avgADT=Math.round(a.adts.reduce(function(s,v){return s+v;},0)/Math.max(a.adts.length,1));
      a.avgAPC=Math.round(a.apcs.reduce(function(s,v){return s+v;},0)/Math.max(a.apcs.length,1));
      delete a.adts;delete a.apcs;return a;
    });
    res.json({success:true,data:result});
  }catch(e){res.status(500).json({success:false,error:e.message});}
});
app.get('/api/mtd/flags',function(req,res){
  try{
    var kpi=readJSON('kpi_mar2026.json',{});
    var master=readJSON('stores.json',[]);
    var kd=kpi.stores||{};
    var flags=[];
    master.forEach(function(s){
      var d=kd[s.name]||kd['TH '+s.name]||{};
      if(d.donut>0&&d.donut<45) flags.push({store:s.name,am:s.am,flag:'Donuts below 45/day',value:d.donut});
      if(d.timbit>0&&d.timbit<100) flags.push({store:s.name,am:s.am,flag:'Timbits below 100/day',value:d.timbit});
      if(d.water>0&&d.water<10) flags.push({store:s.name,am:s.am,flag:'Water bottles below 10/day',value:d.water});
    });
    res.json({success:true,data:flags});
  }catch(e){res.status(500).json({success:false,error:e.message});}
});

app.use(express.static(path.join(__dirname, 'public')));

// ── INDIA CITY NEWS ──────────────────────────────────────
var newsCache={data:null,ts:0};
app.get('/api/news/india',function(req,res){
  var now=Date.now();
  if(newsCache.data&&(now-newsCache.ts)<5*60*1000){
    return res.json({success:true,data:newsCache.data,cached:true});
  }
  var https=require('https');
  var cities=[
    {name:'Delhi',q:'Delhi+business+economy+retail'},
    {name:'Mumbai',q:'Mumbai+business+economy+retail'},
    {name:'Chandigarh',q:'Chandigarh+Punjab+business+economy'},
    {name:'Pune',q:'Pune+business+economy+retail'},
    {name:'Ahmedabad',q:'Ahmedabad+Gujarat+business+economy'},
    {name:'Bengaluru',q:'Bengaluru+business+economy+retail'},
    {name:'Hyderabad',q:'Hyderabad+business+economy+retail'},
    {name:'MPEH',q:'Mumbai+Pune+Expressway+highway+business'},
    {name:'Delhi Airport',q:'Delhi+IGI+airport+business+travel+footfall'},
    {name:'Bengaluru Airport',q:'Bengaluru+BIAL+airport+business+travel'},
    {name:'Hyderabad Airport',q:'Hyderabad+RGIA+airport+business+travel'},
    {name:'Ahmedabad Airport',q:'Ahmedabad+airport+business+travel'}
  ];
  var results=[];
  var done=0;
  cities.forEach(function(city){
    var opts={
      hostname:'news.google.com',
      path:'/rss/search?q='+city.q+'&hl=en-IN&gl=IN&ceid=IN:en',
      method:'GET',
      headers:{'User-Agent':'Mozilla/5.0'}
    };
    var req2=https.request(opts,function(r){
      var d='';
      r.on('data',function(c){d+=c;});
      r.on('end',function(){
        try{
          var items=[];var sp=0;while(true){var s=d.indexOf('<item>',sp),e=d.indexOf('</item>',sp);if(s<0||e<0)break;items.push(d.substring(s,e+7));sp=e+7;}
          items.slice(0,2).forEach(function(item){
            var title=[null,'']; var tc1=item.indexOf('<title>'),tc2=item.indexOf('</title>'); if(tc1>-1&&tc2>-1){var tr=item.substring(tc1+7,tc2); if(tr.indexOf('CDATA')>-1){tr=tr.replace(/<![CDATA[/,'').replace(/]]>/,'');} title=[null,tr.trim()];}
            var link=[null,'']; var lc1=item.indexOf('<link>'),lc2=item.indexOf('</link>'); if(lc1>-1&&lc2>-1){link=[null,item.substring(lc1+6,lc2).trim()];}
            var pubDate=[null,'']; var pc1=item.indexOf('<pubDate>'),pc2=item.indexOf('</pubDate>'); if(pc1>-1&&pc2>-1){pubDate=[null,item.substring(pc1+9,pc2).trim()];}
            var source=[null,'']; var sc1=item.indexOf('>',item.indexOf('<source')),sc2=item.indexOf('</source>'); if(sc1>-1&&sc2>-1){source=[null,item.substring(sc1+1,sc2).trim()];}  
            if(title[1]&&title[1].length>10){
              results.push({
                city:city.name,
                title:title[1].replace(/ - .*$/,'').trim(),
                source:source[1]||'Google News',
                pubDate:pubDate[1]||'',
                link:link[1]||''
              });
            }
          });
        }catch(e){}
        done++;
        if(done===cities.length){
          newsCache={data:results,ts:Date.now()};
          res.json({success:true,data:results,cached:false});
        }
      });
    });
    req2.on('error',function(){done++;if(done===cities.length)res.json({success:true,data:results,cached:false});});
    req2.end();
  });
});

// ── WORLD NEWS ───────────────────────────────────────────
var worldCache={data:null,ts:0};
app.get('/api/news/world',function(req,res){
  var now=Date.now();
  if(worldCache.data&&(now-worldCache.ts)<5*60*1000){
    return res.json({success:true,data:worldCache.data,cached:true});
  }
  var https=require('https');
  var topics=[
    {name:'India Economy',q:'India+GDP+economy+growth+RBI',color:'#FF9500'},
    {name:'Consumer Spending',q:'India+consumer+spending+retail+QSR+food',color:'#34C759'},
    {name:'Oil & Fuel',q:'crude+oil+petrol+diesel+India+price',color:'#FF3B30'},
    {name:'Rupee & Markets',q:'rupee+dollar+Sensex+Nifty+India+markets',color:'#007AFF'},
    {name:'Food & Hospitality',q:'India+food+restaurant+hospitality+industry',color:'#FF6B35'},
    {name:'Airport & Travel',q:'India+airport+aviation+travel+passenger+footfall',color:'#AF52DE'}
  ];
  var results=[];
  var done=0;
  topics.forEach(function(topic){
    var opts={
      hostname:'news.google.com',
      path:'/rss/search?q='+topic.q+'&hl=en-IN&gl=IN&ceid=IN:en',
      method:'GET',
      headers:{'User-Agent':'Mozilla/5.0'}
    };
    var req2=https.request(opts,function(r){
      var d='';
      r.on('data',function(c){d+=c;});
      r.on('end',function(){
        try{
          var items=[];var sp=0;
          while(true){var s=d.indexOf('<item>',sp),e=d.indexOf('</item>',sp);if(s<0||e<0)break;items.push(d.substring(s,e+7));sp=e+7;}
          items.slice(0,2).forEach(function(item){
            var title=[null,'']; var tc1=item.indexOf('<title>'),tc2=item.indexOf('</title>'); if(tc1>-1&&tc2>-1){var tr=item.substring(tc1+7,tc2); if(tr.indexOf('CDATA')>-1){tr=tr.replace('<![CDATA[','').replace(']]>','');} title=[null,tr.trim()];}
            var link=[null,'']; var lc1=item.indexOf('<link>'),lc2=item.indexOf('</link>'); if(lc1>-1&&lc2>-1){link=[null,item.substring(lc1+6,lc2).trim()];}
            var pubDate=[null,'']; var pc1=item.indexOf('<pubDate>'),pc2=item.indexOf('</pubDate>'); if(pc1>-1&&pc2>-1){pubDate=[null,item.substring(pc1+9,pc2).trim()];}
            var source=[null,'']; var sc1=item.indexOf('>',item.indexOf('<source')),sc2=item.indexOf('</source>'); if(sc1>-1&&sc2>-1){source=[null,item.substring(sc1+1,sc2).trim()];}
            if(title[1]&&title[1].length>10){
              results.push({topic:topic.name,color:topic.color,title:title[1].split(' - ')[0].trim(),source:source[1]||'Google News',pubDate:pubDate[1]||'',link:link[1]||''});
            }
          });
        }catch(e){}
        done++;
        if(done===topics.length){worldCache={data:results,ts:Date.now()};res.json({success:true,data:results});}
      });
    });
    req2.on('error',function(){done++;if(done===topics.length)res.json({success:true,data:results});});
    req2.end();
  });
});


// SAP PDF UPLOAD
var sapSt=multer.diskStorage({destination:function(req,file,cb){require("fs").mkdirSync("uploads/sap/",{recursive:true});cb(null,"uploads/sap/");},filename:function(req,file,cb){cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"));}});
var sapUp=multer({storage:sapSt,limits:{fileSize:20*1024*1024}});
app.post("/api/sap/upload-pdf",sapUp.single("pdf"),function(req,res){
  if(!req.file) return res.status(400).json({success:false,error:"No file"});
  var fp=req.file.path, fn=req.file.originalname;
  var spawn=require("child_process").spawn;
  var lines=["import pdfplumber,re,json","def pn(s):","  if not s or str(s).strip() in ['-','','None']: return 0","  s=re.sub(r'[^\\d]','',str(s).strip())","  return int(s) if s else 0","result={}","report_date=None","days=None","with pdfplumber.open('"+fp+"') as pdf:"," page=pdf.pages[0]"," text=page.extract_text() or ''"," m=re.search(r'Report Date:\\s*(\\d{2})-(\\d{2})-(\\d{4})',text)"," if m:"+"  d,mo,y=m.groups()","  report_date=f'{y}-{mo}-{d}'","  days=int(d)"," tables=page.extract_tables()"," if tables:","  regions={'Delhi','Karnataka','Telangana','Maharashtra','Gujarat','Punjab'}","  for row in tables[0]:","   if not row or len(row)<7: continue","   region=str(row[1] or '').strip()","   if region not in regions: continue","   store=str(row[3] or '').strip()","   if not store or store=='Total': continue","   adt=pn(row[4]);apc=pn(row[5]);sales=pn(row[6])","   ads=sales//days if days and days>0 else 0","   result[store]={'ads':ads,'adt':adt,'apc':apc,'salesMTD':sales,'region':region}","total=sum(s['salesMTD'] for s in result.values())","valid=[s for s in result.values() if s['adt']>0]","avg_adt=sum(s['adt'] for s in valid)//len(valid) if valid else 0","avg_apc=sum(s['apc'] for s in valid)//len(valid) if valid else 0","print(json.dumps({'month':report_date[:7] if report_date else None,'reportDate':report_date,'days':days,'summary':{'totalMTDSales':total,'avgADT':avg_adt,'avgAPC':avg_apc,'storeCount':len(result),'indiaADT':avg_adt,'indiaAPC':avg_apc},'stores':result}))"];
  var py=spawn("python3",["/root/th-am-ops-staging/sap_parser.py",fp]);
  var out="",err="";
  py.stdout.on("data",function(d){out+=d.toString();});
  py.stderr.on("data",function(d){err+=d.toString();});
  py.on("close",function(code){
    if(code!==0) return res.status(500).json({success:false,error:"Parse failed: "+err.substring(0,200)});
    try{
      var data=JSON.parse(out.trim());
      var month=data.month;
      writeJSON("kpi_"+month.replace("-","")+".json",data);
      writeJSON("kpi_latest.json",data);
      var history=readJSON("sap_uploads.json",[]);
      history.unshift({filename:fn,month:month,reportDate:data.reportDate,days:data.days,storeCount:data.summary.storeCount,totalMTD:data.summary.totalMTDSales,avgADT:data.summary.avgADT,uploadedAt:new Date().toISOString()});
      if(history.length>20) history=history.slice(0,20);
      writeJSON("sap_uploads.json",history);
      res.json({success:true,message:"Updated "+data.summary.storeCount+" stores for "+month,data:{month:month,storeCount:data.summary.storeCount,days:data.days,totalMTD:data.summary.totalMTDSales,avgADT:data.summary.avgADT,avgAPC:data.summary.avgAPC}});
    }catch(e){res.status(500).json({success:false,error:"Parse error: "+e.message});}
  });
});
app.get("/api/sap/history",function(req,res){res.json({success:true,data:readJSON("sap_uploads.json",[])});});
app.use("/uploads/sap",require("express").static("uploads/sap"));

app.post('/api/sap/parse-direct',function(req,res){
  var month=req.body.month||'2026-04';
  var kpiFile='kpi_'+month.replace('-','')+'.json';
  var data=readJSON(kpiFile,null);
  if(!data||!data.stores){return res.status(404).json({success:false,error:'No data for '+month});}
  var history=readJSON('sap_uploads.json',[]);
  history.unshift({filename:'Manual-'+month+'.pdf',month:month,reportDate:data.reportDate||month+'-01',days:data.days||10,storeCount:data.summary?data.summary.storeCount:44,totalMTD:data.summary?data.summary.totalMTDSales:0,avgADT:data.summary?data.summary.avgADT:0,uploadedAt:new Date().toISOString()});
  if(history.length>20)history=history.slice(0,20);
  writeJSON('sap_uploads.json',history);
  writeJSON('kpi_latest.json',data);
  res.json({success:true,message:'Loaded '+month+' data - '+(data.summary?data.summary.storeCount:0)+' stores',data:{month:month,storeCount:data.summary?data.summary.storeCount:0,days:data.days||10,totalMTD:data.summary?data.summary.totalMTDSales:0,avgADT:data.summary?data.summary.avgADT:0,avgAPC:data.summary?data.summary.avgAPC:0}});
});
// ── Checklist Urgency ────────────────────────────────────────────────────────
app.get('/api/checklist-urgency', function(req, res) {
  try {
    var am = (req.query.am || '').trim();
    var submissions = readJSON('submissions.json', []);
    var audits = readJSON('audits.json', {});
    var amStores = audits.am_stores || {};
    var today = new Date();
    var todayStr = today.toISOString().slice(0, 10);
    var dayName = today.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();

    if (dayName === 'thursday') return res.json({ success: true, restDay: true });

    var isRemoteDay = dayName === 'monday';
    var todaySubs = submissions.filter(function(s) {
      return (s.submittedAt || s.timestamp || '').slice(0, 10) === todayStr;
    });

    function amStatus(amName) {
      var myStores = amStores[amName] || [];
      var submitted = todaySubs.filter(function(s) { return s.am === amName; });
      var submittedNames = submitted.map(function(s) { return (s.store || '').replace('TH ', ''); });
      if (isRemoteDay) {
        var pending = myStores.filter(function(store) {
          var short = store.replace('TH ', '');
          return submittedNames.indexOf(short) < 0 && submittedNames.indexOf(store) < 0;
        });
        return { am: amName, total: myStores.length, submitted: myStores.length - pending.length, pending: pending.length };
      } else {
        var done = submitted.length > 0 ? 1 : 0;
        return { am: amName, total: 1, submitted: done, pending: 1 - done };
      }
    }

    if (am) return res.json({ success: true, day: dayName, isRemoteDay: isRemoteDay, data: amStatus(am) });
    var all = Object.keys(amStores).map(amStatus);
    res.json({ success: true, day: dayName, isRemoteDay: isRemoteDay, data: all });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// ── Activity Feed ─────────────────────────────────────────────────────────────
app.get('/api/activity-feed', function(req, res) {
  try {
    var visits = readJSON('am_visits.json', []);
    var submissions = readJSON('submissions.json', []);
    var fduSubs = readJSON('fdu_submissions.json', []);
    var weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate() - 7);
    var events = [];

    visits.forEach(function(v) {
      if (!v.timestamp) return;
      events.push({ type: 'visit', am: v.am, store: v.store.replace('TH ', ''), timestamp: v.timestamp });
    });

    submissions.filter(function(s) { return new Date(s.submittedAt || 0) >= weekAgo; }).forEach(function(s) {
      events.push({ type: 'checklist', am: s.am || '', store: (s.store || '').replace('TH ', ''), day: s.day || '', timestamp: s.submittedAt || '' });
    });

    fduSubs.filter(function(s) { return new Date(s.submittedAt || 0) >= weekAgo; }).forEach(function(s) {
      events.push({ type: 'fdu', am: s.am || '', store: (s.store || '').replace('TH ', ''), timestamp: s.submittedAt || '' });
    });

    events.sort(function(a, b) { return new Date(b.timestamp || 0) - new Date(a.timestamp || 0); });
    res.json({ success: true, data: events.slice(0, 25) });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// ── AM Store Visit Tracking ──────────────────────────────────────────────────
app.post('/api/am-visits', function(req, res) {
  try {
    var am = (req.body.am || '').trim();
    var store = (req.body.store || '').trim();
    if (!am || !store) return res.status(400).json({ success: false, error: 'am and store required' });
    var date = new Date().toISOString().slice(0, 10); // YYYY-MM-DD in UTC
    var visits = readJSON('am_visits.json', []);
    var todayVisits = visits.filter(function(v) { return v.am === am && v.date === date; });
    if (todayVisits.length >= 2) return res.status(400).json({ success: false, error: 'Max 2 store visits per day' });
    if (todayVisits.some(function(v) { return v.store === store; })) return res.json({ success: true, already: true });
    visits.push({ id: Date.now().toString(), am: am, store: store, date: date, timestamp: new Date().toISOString() });
    if (!writeJSON('am_visits.json', visits)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.delete('/api/am-visits', function(req, res) {
  try {
    var am = (req.body.am || '').trim();
    var store = (req.body.store || '').trim();
    if (!am || !store) return res.status(400).json({ success: false, error: 'am and store required' });
    var date = new Date().toISOString().slice(0, 10);
    var visits = readJSON('am_visits.json', []);
    var before = visits.length;
    visits = visits.filter(function(v) { return !(v.am === am && v.store === store && v.date === date); });
    if (!writeJSON('am_visits.json', visits)) return res.status(500).json({ success: false, error: 'Save failed' });
    res.json({ success: true, removed: before - visits.length });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.get('/api/am-visits', function(req, res) {
  try {
    var am = req.query.am || '';
    var period = req.query.period || 'today';
    var visits = readJSON('am_visits.json', []);
    var now = new Date();
    var today = now.toISOString().slice(0, 10);

    if (period === 'today') {
      var filtered = visits.filter(function(v) { return (!am || v.am === am) && v.date === today; });
      return res.json({ success: true, data: filtered });
    }
    if (period === 'week') {
      var day = now.getDay(); // 0=Sun
      var monday = new Date(now); monday.setDate(now.getDate() - ((day + 6) % 7)); monday.setHours(0,0,0,0);
      var sunday = new Date(monday); sunday.setDate(monday.getDate() + 6); sunday.setHours(23,59,59,999);
      var filtered = visits.filter(function(v) {
        var d = new Date(v.date); return (!am || v.am === am) && d >= monday && d <= sunday;
      });
      // Build day-by-day summary
      var byDay = {};
      filtered.forEach(function(v) { if (!byDay[v.date]) byDay[v.date] = []; byDay[v.date].push(v.store); });
      return res.json({ success: true, data: filtered, byDay: byDay, weekStart: monday.toISOString().slice(0,10), weekEnd: sunday.toISOString().slice(0,10) });
    }
    if (period === 'month') {
      var ym = today.slice(0, 7); // YYYY-MM
      var filtered = visits.filter(function(v) { return (!am || v.am === am) && v.date.startsWith(ym); });
      var storesVisited = {};
      filtered.forEach(function(v) { storesVisited[v.store] = (storesVisited[v.store] || 0) + 1; });
      var allStores = readJSON('stores.json', []);
      var myStores = am ? allStores.filter(function(s) { return s.am && s.am.toLowerCase() === am.toLowerCase(); }) : allStores;
      return res.json({ success: true, data: filtered, storesVisited: storesVisited, totalStores: myStores.length, uniqueVisited: Object.keys(storesVisited).length });
    }
    if (period === 'all') {
      var filtered = am ? visits.filter(function(v) { return v.am === am; }) : visits;
      return res.json({ success: true, data: filtered });
    }
    res.json({ success: true, data: visits.filter(function(v) { return !am || v.am === am; }) });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.get('/api/am-visits/hod-summary', function(req, res) {
  try {
    var visits = readJSON('am_visits.json', []);
    var now = new Date();
    var today = now.toISOString().slice(0, 10);
    var ym = today.slice(0, 7);
    var day = now.getDay();
    var monday = new Date(now); monday.setDate(now.getDate() - ((day + 6) % 7)); monday.setHours(0,0,0,0);
    var allStores = readJSON('stores.json', []);
    var ams = {};
    allStores.forEach(function(s) { if (s.am) ams[s.am] = (ams[s.am] || 0) + 1; });
    var summary = Object.keys(ams).map(function(am) {
      var amVisits = visits.filter(function(v) { return v.am === am; });
      var todayV = amVisits.filter(function(v) { return v.date === today; });
      var weekV = amVisits.filter(function(v) { var d = new Date(v.date); return d >= monday; });
      var monthV = amVisits.filter(function(v) { return v.date.startsWith(ym); });
      var monthStores = {};
      monthV.forEach(function(v) { monthStores[v.store] = true; });
      return { am: am, totalStores: ams[am], todayVisits: todayV.map(function(v){return v.store;}), weekVisitDays: [...new Set(weekV.map(function(v){return v.date;}))].length, monthUniqueStores: Object.keys(monthStores).length };
    });
    res.json({ success: true, data: summary, today: today });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// ── Weekly Top 3 Auto-Recognition Engine ─────────────────────────────────────
var CELEBRATION_PRODUCTS = [
  { name: 'Boston Cream Donut',  file: 'boston-cream-donut.png' },
  { name: 'Chocolate Dip Donut', file: 'choc-dip-donut.png' },
  { name: 'Vanilla Dip Donut',   file: 'vanilla-dip-donut.png' },
  { name: 'Maple Caramel Donut', file: 'maple-caramel-donut.png' },
  { name: 'Brownie Donut',       file: 'brownie-donut.png' },
  { name: 'Blueberry Donut',     file: 'blueberry-donut.png' },
  { name: 'Triple Choc Cookie',  file: 'triple-choc-cookie.png' },
  { name: 'Blueberry Muffin',    file: 'blueberry-muffin.png' },
  { name: 'Chocolate Brownie',   file: 'chocolate-brownie.png' },
  { name: 'Almond Croissant',    file: 'almond-croissant.png' },
  { name: 'French Vanilla',      file: 'french-vanilla.png' },
  { name: 'Kadak Chai',          file: 'kadak-chai.png' },
  { name: 'Java Chip Iced Capp', file: 'java-chip-iced-capp.png' }
];

var RANK_LABELS = ['🥇','🥈','🥉'];

var RECOGNITION_LINES = [
  function(am, pct, n, product, rank) { return rank + ' ' + am + ' is in the top 3 this week — ' + pct + '% checklist completion across ' + n + ' store' + (n!==1?'s':'') + '! Sending over a ' + product + ' as a sweet treat 🎉☕'; },
  function(am, pct, n, product, rank) { return rank + ' ' + am.split(' ')[0] + ' is absolutely on fire — ' + pct + '% this week, ' + n + ' store' + (n!==1?'s':'') + ' ticked off perfectly. A ' + product + ' is well earned 🔥🏆'; },
  function(am, pct, n, product, rank) { return rank + ' Shoutout to ' + am.split(' ')[0] + ' — ' + pct + '% completion this week, top 3 in the network! Here\'s a ' + product + ' from the whole team 🎊'; },
  function(am, pct, n, product, rank) { return rank + ' ' + am.split(' ')[0] + ' doesn\'t miss. Top 3, ' + pct + '% across ' + n + ' store' + (n!==1?'s':'') + ' — exceptional week. Enjoy a ' + product + ', you\'ve earned it ☕👑'; },
  function(am, pct, n, product, rank) { return rank + ' ' + am.split(' ')[0] + ' in the top 3 with ' + pct + '% — ' + n + ' store' + (n!==1?'s':'') + ', zero excuses, all excellence. A ' + product + ' heading your way 💪🍩'; },
  function(am, pct, n, product, rank) { return rank + ' What a week for ' + am.split(' ')[0] + '! ' + pct + '% checklist completion — that\'s the standard. Treating you to a ' + product + ' 🌟☕'; }
];

function getWeekKey(date) {
  var d = date || new Date();
  var day = d.getDay();
  var mon = new Date(d); mon.setDate(d.getDate() - ((day + 6) % 7)); mon.setHours(0,0,0,0);
  return mon.toISOString().slice(0,10); // e.g. "2026-05-25"
}

function calcWeeklyCompletionRankings() {
  var now = new Date();
  var day = now.getDay();
  var monday = new Date(now); monday.setDate(now.getDate() - ((day + 6) % 7)); monday.setHours(0,0,0,0);
  var REMOTE_DAYS = ['monday','tuesday'];
  var REST_DAYS   = ['thursday'];

  var audits = readJSON('audits.json', {});
  var amStores = audits.am_stores || {};
  var submissions = readJSON('submissions.json', []);

  // Submissions this week
  var weekSubs = submissions.filter(function(s) {
    var d = new Date(s.submittedAt || s.date || 0);
    return d >= monday && d <= now && (s.scoredItems > 0 || (s.score||0) > 0 || s.day);
  });

  // Expected count per AM for days Mon → today
  function expectedForAM(amName) {
    var storeList = amStores[amName] || [];
    var n = storeList.length;
    var expected = 0;
    for (var d = new Date(monday); d <= now; d.setDate(d.getDate() + 1)) {
      var dn = d.toLocaleDateString('en-US', {weekday:'long'}).toLowerCase();
      if (REST_DAYS.indexOf(dn) >= 0) continue;
      if (REMOTE_DAYS.indexOf(dn) >= 0) expected += n;
      else expected += 1; // one on-site store
    }
    return expected;
  }

  var rankings = Object.keys(amStores).map(function(am) {
    var storeList = amStores[am] || [];
    var submitted = weekSubs.filter(function(s) { return s.am === am; }).length;
    var expected  = expectedForAM(am);
    var pct       = expected > 0 ? Math.round(submitted / expected * 100) : 0;
    return { am: am, submitted: submitted, expected: expected, pct: Math.min(pct, 100), storeCount: storeList.length };
  });

  // Sort: highest pct first, tiebreak by submitted count
  rankings.sort(function(a, b) {
    if (b.pct !== a.pct) return b.pct - a.pct;
    return b.submitted - a.submitted;
  });

  return rankings;
}

function checkWeeklyTop3AutoPost(triggerAM) {
  // Only post once per week — the #1 performer only
  var weekKey = getWeekKey();
  var log = readJSON('auto_recognition_log.json', {});
  if (log[weekKey] && log[weekKey]._fired) return; // already recognized this week

  var rankings = calcWeeklyCompletionRankings();
  var top1 = rankings.filter(function(r) { return r.pct > 0 && r.submitted > 0; })[0];
  if (!top1) return;

  var product = CELEBRATION_PRODUCTS[Math.floor(Math.random() * CELEBRATION_PRODUCTS.length)];
  var lineFn = RECOGNITION_LINES[Math.floor(Math.random() * RECOGNITION_LINES.length)];
  var caption = lineFn(top1.am, top1.pct, top1.storeCount, product.name, RANK_LABELS[0]);

  var post = {
    id: 'rec_' + weekKey + '_' + Date.now(),
    author: 'Jahid',
    category: 'recognition',
    store: 'Tim Hortons India',
    taggedPerson: top1.am,
    caption: caption,
    photo: '/images/products/' + product.file,
    isProduct: true,
    isAutoPost: true,
    reactions: { '❤️': 0, '🔥': 0, '👏': 0, '⭐': 0, '☕': 0 },
    comments: [],
    prodReactions: {},
    createdAt: new Date().toISOString(),
    timeAgo: 'Just now'
  };

  var posts = readJSON('posts.json', []);
  posts.unshift(post);
  writeJSON('posts.json', posts);

  log[weekKey] = { _fired: true, am: top1.am, postedAt: new Date().toISOString(), pct: top1.pct, product: product.name };
  writeJSON('auto_recognition_log.json', log);

  setImmediate(function() { sendFeedPostEmail(post); });
  console.log('[AutoPost] Weekly top performer: ' + top1.am + ' ' + top1.pct + '% with ' + product.name);
}

// ── Weekly Leaderboard Engine ─────────────────────────────────────────────────

function computeWeeklyLeaderboardData() {
  var now = new Date();
  var sevenDaysAgo = new Date(now);
  sevenDaysAgo.setDate(now.getDate() - 7);
  sevenDaysAgo.setHours(0, 0, 0, 0);

  var submissions = readJSON('submissions.json', []);
  var fduSubs     = readJSON('fdu_submissions.json', []);
  var storesData  = readJSON('stores.json', []);

  var fmt = function(d) { return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }); };
  var weekLabel = fmt(sevenDaysAgo) + ' – ' + fmt(now);

  var weekSubs = submissions.filter(function(s) {
    var d = new Date(s.submittedAt || s.date || 0);
    return d >= sevenDaysAgo && d <= now;
  });
  var weekFdu = fduSubs.filter(function(s) {
    var d = new Date(s.submittedAt || s.date || 0);
    return d >= sevenDaysAgo && d <= now;
  });

  var amNames = Object.keys(AM_EMAILS).filter(function(am) { return am !== 'Jahid'; });

  var rankings = amNames.map(function(am) {
    var amStores   = storesData.filter(function(s) { return s.am === am; });
    var totalStores = amStores.length;

    var amSubs  = weekSubs.filter(function(s) { return s.am === am; });
    var visits  = amSubs.length;
    var scores  = amSubs.map(function(s) { return s.score || 0; }).filter(function(x) { return x > 0; });
    var avgScore = scores.length > 0
      ? Math.round(scores.reduce(function(a, b) { return a + b; }, 0) / scores.length)
      : null;

    var uniqueStores = {};
    amSubs.forEach(function(s) { if (s.store) uniqueStores[s.store] = true; });
    var storesCovered = Object.keys(uniqueStores).length;
    var coveragePct   = totalStores > 0 ? Math.round(storesCovered / totalStores * 100) : 0;

    var fduCount = weekFdu.filter(function(s) { return s.am === am; }).length;
    var fduScore = Math.min(fduCount * 20, 100);

    // Composite: 40% coverage + 40% checklist score + 20% FDU
    var composite = Math.round(
      coveragePct * 0.4 +
      (avgScore !== null ? avgScore : 0) * 0.4 +
      fduScore * 0.2
    );

    return { am: am, visits: visits, avgScore: avgScore, coveragePct: coveragePct,
             storesCovered: storesCovered, totalStores: totalStores, fduSubs: fduCount, composite: composite };
  });

  rankings.sort(function(a, b) {
    if (b.composite !== a.composite) return b.composite - a.composite;
    return b.visits - a.visits;
  });

  var medals = ['🥇', '🥈', '🥉'];
  rankings.forEach(function(r, i) { r.rank = i + 1; r.medal = medals[i] || '#' + (i + 1); });

  var withScores = rankings.filter(function(r) { return r.avgScore !== null; });
  var teamAvg = withScores.length > 0
    ? Math.round(withScores.reduce(function(s, r) { return s + r.avgScore; }, 0) / withScores.length)
    : 0;

  return {
    weekLabel: weekLabel,
    weekKey: getWeekKey(),
    rankings: rankings,
    teamAvg: teamAvg,
    totalVisits: weekSubs.length,
    mvp: rankings[0] && rankings[0].visits > 0 ? rankings[0].am : null
  };
}

function postWeeklyLeaderboard() {
  var weekKey = getWeekKey();
  var log = readJSON('leaderboard_post_log.json', {});
  if (log[weekKey]) {
    console.log('[Leaderboard] Already posted for week ' + weekKey);
    return;
  }

  var data = computeWeeklyLeaderboardData();
  var top3 = data.rankings.filter(function(r) { return r.visits > 0; }).slice(0, 3);

  var lines = ['🏆 Weekly Leaderboard — ' + data.weekLabel + '\n\nThis week\'s top performers:'];
  top3.forEach(function(r) {
    var scoreStr = r.avgScore !== null ? r.avgScore + '% score' : 'no scores yet';
    lines.push(r.medal + ' ' + r.am + ' — ' + r.visits + ' visits · ' + r.coveragePct + '% coverage · ' + scoreStr);
  });
  if (data.mvp) lines.push('\n⭐ MVP this week: ' + data.mvp + '! Keep raising the bar! ☕');
  lines.push('\nTeam avg: ' + data.teamAvg + '% · ' + data.totalVisits + ' total store visits this week');
  var caption = lines.join('\n');

  var post = {
    id: 'lb_' + Date.now(),
    author: 'Jahid',
    category: 'leaderboard',
    store: 'Tim Hortons India',
    caption: caption,
    isAutoPost: true,
    isLeaderboard: true,
    leaderboardData: data,
    reactions: { '❤️': 0, '🔥': 0, '👏': 0, '⭐': 0, '☕': 0 },
    comments: [],
    prodReactions: {},
    createdAt: new Date().toISOString(),
    timeAgo: 'Just now'
  };

  var posts = readJSON('posts.json', []);
  posts.unshift(post);
  writeJSON('posts.json', posts);
  log[weekKey] = { postedAt: new Date().toISOString() };
  writeJSON('leaderboard_post_log.json', log);
  console.log('[Leaderboard] Posted for ' + data.weekLabel + ' · MVP: ' + (data.mvp || 'none'));
  setImmediate(function() { sendFeedPostEmail(post); });
}

// Expose via API so it can be manually triggered or tested
app.post('/api/auto-recognition/run', function(req, res) {
  try {
    var rankings = calcWeeklyCompletionRankings();
    checkWeeklyTop3AutoPost(null);
    res.json({ success: true, rankings: rankings.slice(0, 5) });
  } catch(e) { res.status(500).json({ success: false, error: e.message }); }
});

app.get('/api/auto-recognition/rankings', function(req, res) {
  try {
    var rankings = calcWeeklyCompletionRankings();
    var weekKey = getWeekKey();
    var log = readJSON('auto_recognition_log.json', {});
    res.json({ success: true, weekKey: weekKey, rankings: rankings, alreadyPosted: log[weekKey] || {} });
  } catch(e) { res.status(500).json({ success: false, error: e.message }); }
});

app.post('/api/leaderboard/run', function(req, res) {
  try {
    var data = computeWeeklyLeaderboardData();
    var weekKey = getWeekKey();
    var log = readJSON('leaderboard_post_log.json', {});
    var force = req.body && req.body.force;
    if (log[weekKey] && !force) {
      return res.json({ success: false, alreadyPosted: true, postedAt: log[weekKey].postedAt, data: data });
    }
    // Allow force re-post by clearing this week's log entry
    if (force) delete log[weekKey];
    writeJSON('leaderboard_post_log.json', log);
    postWeeklyLeaderboard();
    res.json({ success: true, weekKey: weekKey, data: data });
  } catch(e) { res.status(500).json({ success: false, error: e.message }); }
});

app.get('/api/leaderboard/preview', function(req, res) {
  try {
    var data = computeWeeklyLeaderboardData();
    var log = readJSON('leaderboard_post_log.json', {});
    res.json({ success: true, data: data, alreadyPosted: log[data.weekKey] || null });
  } catch(e) { res.status(500).json({ success: false, error: e.message }); }
});

// ── Festival Greeting Engine ──────────────────────────────────────────────────

var FESTIVALS = [
  // Fixed-date festivals (MM-DD recurring every year)
  { name: 'New Year', key: 'new-year', recurring: true, date: '01-01',
    emoji: '🎆', bg1: '#0D0D2B', bg2: '#1A1A5E', accent: '#FFD700',
    caption: "🎆 Happy New Year! 🥂\n\nA brand new year, a fresh page, new goals — and the same incredible team that makes it all happen. Thank you each one of you for an amazing journey. Let's make this year even bigger! ☕🔥\n\n— Jahid",
    greeting: ["Wishing our entire Tim's family", "a sparkling New Year! 🥂", "New goals. Same great team.", "Let's make it incredible! ☕"] },

  { name: 'Lohri', key: 'lohri', recurring: true, date: '01-13',
    emoji: '🔥', bg1: '#7B2D00', bg2: '#D35400', accent: '#FFD700',
    caption: "🔥 Happy Lohri! 🌾\n\nMay the warmth of the bonfire fill your homes with joy, prosperity and love. Here's to celebrating the harvest season with the spirit of togetherness! 🙏\n\n— Jahid",
    greeting: ["Happy Lohri! 🌾", "May the bonfire bring warmth,", "joy and prosperity to your family!", "Keep the Tim's spirit burning bright 🔥"] },

  { name: 'Makar Sankranti & Pongal', key: 'sankranti', recurring: true, date: '01-14',
    emoji: '🪁', bg1: '#E65100', bg2: '#F57F17', accent: '#FFFFFF',
    caption: "🪁 Happy Makar Sankranti & Pongal! 🌤️\n\nAs we celebrate the harvest and the sun's northward journey — may this season bring abundance, new beginnings and endless joy to you and your families! 🙏☕\n\n— Jahid",
    greeting: ["Happy Makar Sankranti", "& Pongal! 🌤️", "May this harvest season", "bring abundance & joy! 🙏"] },

  { name: 'Republic Day', key: 'republic-day', recurring: true, date: '01-26',
    emoji: '🇮🇳', bg1: '#FF6600', bg2: '#138808', accent: '#FFFFFF',
    caption: "🇮🇳 Happy Republic Day!\n\nProud to be building something great in this incredible nation. Every store, every cup, every smile — it's our small contribution to India's story. Jai Hind! 🙏\n\n— Jahid",
    greeting: ["Happy Republic Day! 🇮🇳", "Proud to serve India,", "one cup at a time.", "Jai Hind! 🙏"] },

  { name: 'Baisakhi', key: 'baisakhi', recurring: true, date: '04-14',
    emoji: '🌾', bg1: '#F9A825', bg2: '#E65100', accent: '#FFFFFF',
    caption: "🌾 Happy Baisakhi! 🎉\n\nA festival of harvests, new beginnings and gratitude. Thank you for sowing the seeds of excellence every single day at every Tim's store. The harvest of success is yours! 🙏☕\n\n— Jahid",
    greeting: ["Happy Baisakhi! 🎉", "New season, new energy,", "same incredible Tim's spirit!", "Celebrate the harvest! 🌾"] },

  { name: 'Independence Day', key: 'independence-day', recurring: true, date: '08-15',
    emoji: '🇮🇳', bg1: '#FF9933', bg2: '#138808', accent: '#FFFFFF',
    caption: "🇮🇳 Happy Independence Day! 🎆\n\nFreedom, pride and the spirit of a billion dreams. We are honoured to be part of India's food story. Here's to a nation that inspires us every day — Jai Hind! 🙏\n\n— Jahid",
    greeting: ["Happy Independence Day! 🎆", "Proud to be India's own.", "Freedom, pride, ☕ & Tim's.", "Jai Hind! 🇮🇳"] },

  { name: 'Gandhi Jayanti', key: 'gandhi-jayanti', recurring: true, date: '10-02',
    emoji: '🕊️', bg1: '#1B5E20', bg2: '#2E7D32', accent: '#FFD700',
    caption: "🕊️ Happy Gandhi Jayanti!\n\nOn the birth anniversary of the Father of the Nation, let us be inspired by his values — truth, integrity, and dedication. Values we carry in every Tim's store every day. 🙏\n\n— Jahid",
    greeting: ["Happy Gandhi Jayanti! 🕊️", "Inspired by truth &", "integrity every day.", "Jai Gandhi Ji! 🙏"] },

  { name: 'Christmas', key: 'christmas', recurring: true, date: '12-25',
    emoji: '🎄', bg1: '#1B5E20', bg2: '#B71C1C', accent: '#FFD700',
    caption: "🎄 Merry Christmas & Happy Holidays! 🎁\n\nMay this festive season bring warmth, joy and togetherness to you and your loved ones. Wishing you all the peace and happiness you deserve! ☕🎅\n\n— Jahid",
    greeting: ["Merry Christmas! 🎄", "May joy, warmth & love", "fill your festive season!", "Happy Holidays! 🎁☕"] },

  // Variable festivals — 2026 dates (update annually)
  { name: 'Holi', key: 'holi', recurring: false, date: '2026-03-25',
    emoji: '🎨', bg1: '#AD1457', bg2: '#F57F17', accent: '#FFFFFF',
    caption: "🎨 Happy Holi! 🌈\n\nMay the festival of colours splash your life with joy, love, laughter and endless happy moments! Bura na mano, Holi hai! 🎊 Wishing you all the brightest colours this season! ☕\n\n— Jahid",
    greeting: ["Happy Holi! 🌈", "May colours of joy, love", "& success fill your life!", "Bura na mano, Holi hai! 🎊"] },

  { name: 'Ram Navami', key: 'ram-navami', recurring: false, date: '2026-03-28',
    emoji: '🪔', bg1: '#B71C1C', bg2: '#E65100', accent: '#FFD700',
    caption: "🪔 Happy Ram Navami! 🙏\n\nOn this sacred day, may the blessings of Lord Ram fill your life with peace, strength and righteousness. Jai Shri Ram! 🙏\n\n— Jahid",
    greeting: ["Happy Ram Navami! 🪔", "May Lord Ram's blessings", "bring peace & strength.", "Jai Shri Ram! 🙏"] },

  { name: 'Buddha Purnima', key: 'buddha-purnima', recurring: false, date: '2026-05-13',
    emoji: '☮️', bg1: '#4A148C', bg2: '#1565C0', accent: '#FFD700',
    caption: "☮️ Happy Buddha Purnima! 🙏\n\nOn this day of enlightenment and compassion, may we all find peace, wisdom and the strength to walk the right path. Wishing everyone a blessed day. 🌸\n\n— Jahid",
    greeting: ["Happy Buddha Purnima! ☮️", "May wisdom, peace &", "compassion light your path.", "Blessed day! 🌸🙏"] },

  { name: 'Janmashtami', key: 'janmashtami', recurring: false, date: '2026-08-24',
    emoji: '🦚', bg1: '#1565C0', bg2: '#4A148C', accent: '#FFD700',
    caption: "🦚 Happy Janmashtami! 🙏\n\nMay the divine energy of Lord Krishna fill your life with joy, wisdom and devotion. Wishing you all a blessed celebration! 🎶 Jai Shri Krishna! 🙏\n\n— Jahid",
    greeting: ["Happy Janmashtami! 🦚", "May Lord Krishna's blessings", "fill your life with joy!", "Jai Shri Krishna! 🙏"] },

  { name: 'Ganesh Chaturthi', key: 'ganesh-chaturthi', recurring: false, date: '2026-08-23',
    emoji: '🐘', bg1: '#E65100', bg2: '#BF360C', accent: '#FFD700',
    caption: "🐘 Ganpati Bappa Morya! 🙏\n\nWishing everyone a blessed Ganesh Chaturthi! May Lord Ganesha remove all obstacles from your path and fill your life with success, wisdom and happiness. Morya! 🎊\n\n— Jahid",
    greeting: ["Ganpati Bappa Morya! 🐘", "May Lord Ganesha bless", "you with success & wisdom!", "Happy Ganesh Chaturthi! 🎊"] },

  { name: 'Navratri', key: 'navratri', recurring: false, date: '2026-10-14',
    emoji: '🪷', bg1: '#880E4F', bg2: '#E91E63', accent: '#FFD700',
    caption: "🪷 Happy Navratri! 🎉\n\nNine nights of devotion, dance and divine energy! May Maa Durga bless you all with strength, courage and prosperity this festive season. Jai Mata Di! 🙏\n\n— Jahid",
    greeting: ["Happy Navratri! 🪷", "May Maa Durga's blessings", "bring strength & prosperity!", "Jai Mata Di! 🙏🎉"] },

  { name: 'Dussehra', key: 'dussehra', recurring: false, date: '2026-10-23',
    emoji: '⚡', bg1: '#E65100', bg2: '#BF360C', accent: '#FFD700',
    caption: "⚡ Happy Dussehra! 🙏\n\nMay the victory of good over evil inspire us to conquer our challenges and rise above with strength and righteousness. Let's build Tim's India with the same conviction! 🏆\n\n— Jahid",
    greeting: ["Happy Dussehra! ⚡", "May good always triumph.", "Rise, conquer, celebrate!", "Victory to righteousness! 🏆"] },

  { name: 'Diwali', key: 'diwali', recurring: false, date: '2026-11-08',
    emoji: '🪔', bg1: '#2D1B69', bg2: '#5C1A1A', accent: '#FFD700',
    caption: "🪔 Happy Diwali! ✨\n\nThis festival of lights is a reminder that no darkness is too deep — your light, your effort, your dedication always wins. Wishing you and your families the brightest, most beautiful Diwali ever! 🎆🙏\n\n— Jahid",
    greeting: ["Happy Diwali! 🪔", "May the festival of lights", "bring joy & prosperity!", "Love from Tim's India ✨🎆"] },

  { name: 'Bhai Dooj', key: 'bhai-dooj', recurring: false, date: '2026-11-10',
    emoji: '🤝', bg1: '#880E4F', bg2: '#AD1457', accent: '#FFD700',
    caption: "🤝 Happy Bhai Dooj! 🌸\n\nCelebrating the beautiful bond of brothers and sisters today. The Tim's India family is a bond just like this — built on trust, love and togetherness! Wishing everyone a wonderful day! 🙏\n\n— Jahid",
    greeting: ["Happy Bhai Dooj! 🤝", "Celebrating the bond of", "brothers & sisters today!", "Love & togetherness 🌸🙏"] },

  { name: 'Guru Nanak Jayanti', key: 'guru-nanak-jayanti', recurring: false, date: '2026-11-23',
    emoji: '✨', bg1: '#E65100', bg2: '#827717', accent: '#FFFFFF',
    caption: "✨ Gurpurab Mubarak! 🙏\n\nOn the sacred occasion of Guru Nanak Dev Ji's birth anniversary, may the light of his teachings — Naam Japo, Kirat Karo, Vand Chakko — guide us all towards a righteous and humble life. Waheguru Ji! 🙏\n\n— Jahid",
    greeting: ["Gurpurab Mubarak! ✨", "May Guru Nanak's light", "guide your every step.", "Waheguru Ji Ka Khalsa! 🙏"] },
];

function escSVG(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function generateFestivalCardSVG(f) {
  var lines = f.greeting;
  var lh = 38;
  var greetY = 470;
  var tspans = lines.map(function(line, i) {
    return '<tspan x="400" dy="' + (i === 0 ? 0 : lh) + '">' + escSVG(line) + '</tspan>';
  }).join('');

  return '<?xml version="1.0" encoding="UTF-8"?>'
    + '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">'
    + '<defs>'
    + '<linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">'
    + '<stop offset="0%" stop-color="' + f.bg1 + '"/>'
    + '<stop offset="100%" stop-color="' + f.bg2 + '"/>'
    + '</linearGradient>'
    + '<linearGradient id="shine" x1="0%" y1="0%" x2="0%" y2="100%">'
    + '<stop offset="0%" stop-color="rgba(255,255,255,0.08)"/>'
    + '<stop offset="100%" stop-color="rgba(0,0,0,0)"/>'
    + '</linearGradient>'
    + '</defs>'
    + '<rect width="800" height="800" fill="url(#bg)"/>'
    + '<rect width="800" height="800" fill="url(#shine)"/>'
    + '<circle cx="0" cy="0" r="220" fill="rgba(255,255,255,0.05)"/>'
    + '<circle cx="800" cy="800" r="280" fill="rgba(255,255,255,0.05)"/>'
    + '<circle cx="800" cy="0" r="140" fill="rgba(255,255,255,0.04)"/>'
    + '<circle cx="0" cy="800" r="140" fill="rgba(255,255,255,0.04)"/>'
    // border frame
    + '<rect x="20" y="20" width="760" height="760" rx="24" ry="24" fill="none" stroke="rgba(255,255,255,0.12)" stroke-width="1.5"/>'
    // TH branding top
    + '<text x="400" y="58" font-size="13" text-anchor="middle" fill="rgba(255,255,255,0.45)" '
    + 'font-family="Arial, Helvetica, sans-serif" letter-spacing="4">TIM HORTONS INDIA</text>'
    + '<line x1="160" y1="70" x2="330" y2="70" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>'
    + '<line x1="470" y1="70" x2="640" y2="70" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>'
    // main emoji
    + '<text x="400" y="245" font-size="148" text-anchor="middle" dominant-baseline="middle" '
    + 'font-family="Segoe UI Emoji, Noto Color Emoji, Apple Color Emoji, sans-serif">' + f.emoji + '</text>'
    // title
    + '<text x="400" y="370" font-size="54" font-weight="bold" text-anchor="middle" fill="' + f.accent + '" '
    + 'font-family="Arial Black, Arial, Helvetica, sans-serif">' + escSVG('Happy ' + f.name + '!') + '</text>'
    // divider
    + '<line x1="250" y1="395" x2="550" y2="395" stroke="rgba(255,255,255,0.25)" stroke-width="1.5"/>'
    // greeting lines
    + '<text x="400" y="' + greetY + '" font-size="24" text-anchor="middle" fill="rgba(255,255,255,0.9)" '
    + 'font-family="Arial, Helvetica, sans-serif">' + tspans + '</text>'
    // TH badge
    + '<circle cx="400" cy="710" r="38" fill="rgba(255,255,255,0.14)" stroke="rgba(255,255,255,0.3)" stroke-width="1.5"/>'
    + '<text x="400" y="717" font-size="22" font-weight="900" text-anchor="middle" fill="white" '
    + 'font-family="Arial Black, Arial, sans-serif">TH</text>'
    // from line
    + '<text x="400" y="765" font-size="14" text-anchor="middle" fill="rgba(255,255,255,0.6)" '
    + 'font-family="Arial, Helvetica, sans-serif">From Jahid 🙏</text>'
    + '</svg>';
}

function getFestivalToday() {
  var today = new Date();
  var mm = String(today.getMonth() + 1).padStart(2, '0');
  var dd = String(today.getDate()).padStart(2, '0');
  var todayFull = today.toISOString().substring(0, 10); // YYYY-MM-DD
  var todayMMDD = mm + '-' + dd;

  return FESTIVALS.filter(function(f) {
    if (f.recurring) return f.date === todayMMDD;
    return f.date === todayFull;
  });
}

function checkAndPostFestivalGreeting() {
  try {
    var todaysFestivals = getFestivalToday();
    if (!todaysFestivals.length) return;

    var log = readJSON('festival_post_log.json', {});
    var today = new Date().toISOString().substring(0, 10);

    todaysFestivals.forEach(function(f) {
      var logKey = today + '_' + f.key;
      if (log[logKey]) return; // already handled today (approved, rejected, or pending)

      // Generate SVG card
      var svgPath = path.join(__dirname, 'public', 'images', 'festivals', f.key + '.svg');
      fs.writeFileSync(svgPath, generateFestivalCardSVG(f), 'utf8');

      // Generate unique approval token
      var token = require('crypto').randomBytes(24).toString('hex');
      var pending = readJSON('festival_pending.json', {});
      pending[token] = { festival: f, date: today, status: 'pending', createdAt: new Date().toISOString() };
      writeJSON('festival_pending.json', pending);

      // Mark as pending in log so we don't send duplicate approval emails
      log[logKey] = { status: 'pending', token: token, festival: f.name, sentAt: new Date().toISOString() };
      writeJSON('festival_post_log.json', log);

      // Send approval email to Jahid
      setImmediate(function() { sendFestivalApprovalEmail(f, token); });
      console.log('[Festival] Approval email sent for ' + f.name);
    });
  } catch (e) {
    console.error('[Festival] Error:', e.message);
  }
}

function sendFestivalApprovalEmail(f, token) {
  var cardImgUrl = 'https://opsaihub.in/images/festivals/' + f.key + '.svg';
  var approveUrl = 'https://opsaihub.in/api/festival/approve?token=' + token;
  var rejectUrl  = 'https://opsaihub.in/api/festival/reject?token=' + token;
  var captionHtml = (f.caption || '').replace(/\n/g, '<br>');

  var html = '<div style="font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:520px;margin:0 auto;background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.12);">'
    + '<div style="background:#C8102E;padding:22px 24px;">'
    +   '<div style="color:#fff;font-size:20px;font-weight:800;">Festival Greeting — Approval Needed ✋</div>'
    +   '<div style="color:rgba(255,255,255,0.8);font-size:13px;margin-top:4px;">Review the creative below before it goes live on Tim\'s Feed</div>'
    + '</div>'
    + '<div style="padding:24px;">'
    +   '<div style="font-size:13px;font-weight:700;color:#C8102E;text-transform:uppercase;letter-spacing:0.6px;margin-bottom:12px;">🎉 ' + f.name + '</div>'
    +   '<img src="' + cardImgUrl + '" style="width:100%;border-radius:14px;margin-bottom:18px;display:block;" alt="' + f.name + ' greeting card">'
    +   '<div style="background:#F5F5F7;border-radius:12px;padding:14px;font-size:14px;color:#1D1D1F;line-height:1.7;margin-bottom:20px;">' + captionHtml + '</div>'
    +   '<div style="display:flex;gap:12px;flex-direction:column;">'
    +     '<a href="' + approveUrl + '" style="display:block;background:#C8102E;color:#fff;border-radius:12px;padding:14px 20px;font-size:15px;font-weight:700;text-decoration:none;text-align:center;">✅ Approve & Post to Feed</a>'
    +     '<a href="' + rejectUrl + '"  style="display:block;background:#E5E5EA;color:#3A3A3C;border-radius:12px;padding:14px 20px;font-size:15px;font-weight:600;text-decoration:none;text-align:center;">❌ Skip — Don\'t Post</a>'
    +   '</div>'
    + '</div>'
    + '<div style="padding:14px 24px;background:#F5F5F7;font-size:11px;color:#8E8E93;">Tim\'s Ops Connect · OpsAIHub — Only you can see this approval link</div>'
    + '</div>';

  sendEmail('jahidrccl@yahoo.com', '🎉 Festival Greeting Ready: ' + f.name + ' — Approve to Post', html, function(){});
}

function publishFestivalPost(f) {
  var post = {
    id: Date.now().toString() + '_fest_' + f.key,
    author: 'Jahid',
    category: 'celebration',
    store: 'Tim Hortons India',
    caption: f.caption,
    photo: '/images/festivals/' + f.key + '.svg',
    isFestivalPost: true,
    festivalKey: f.key,
    festivalName: f.name,
    reactions: { '❤️': 0, '🔥': 0, '👏': 0, '⭐': 0, '☕': 0 },
    comments: [], prodReactions: {},
    createdAt: new Date().toISOString(),
    timeAgo: 'Just now', pinned: false
  };
  var posts = readJSON('posts.json', []);
  posts.unshift(post);
  writeJSON('posts.json', posts);
  return post;
}

app.get('/api/festival/approve', function(req, res) {
  try {
    var token = req.query.token;
    var pending = readJSON('festival_pending.json', {});
    if (!pending[token]) return res.send(festivalResponsePage('Invalid Link', 'This approval link is invalid or has expired.', false));
    if (pending[token].status !== 'pending') {
      var st = pending[token].status;
      return res.send(festivalResponsePage('Already ' + st.charAt(0).toUpperCase() + st.slice(1), 'This greeting was already ' + st + '.', st === 'approved'));
    }
    var f = pending[token].festival;
    publishFestivalPost(f);
    var today = new Date().toISOString().substring(0, 10);
    var log = readJSON('festival_post_log.json', {});
    log[today + '_' + f.key] = { status: 'approved', postedAt: new Date().toISOString(), festival: f.name };
    writeJSON('festival_post_log.json', log);
    pending[token].status = 'approved';
    pending[token].resolvedAt = new Date().toISOString();
    writeJSON('festival_pending.json', pending);
    console.log('[Festival] Approved and posted: ' + f.name);
    res.send(festivalResponsePage('Posted! ✅', 'The ' + f.name + ' greeting is now live on Tim\'s Feed.', true));
  } catch(e) { res.status(500).send('Error: ' + e.message); }
});

app.get('/api/festival/reject', function(req, res) {
  try {
    var token = req.query.token;
    var pending = readJSON('festival_pending.json', {});
    if (!pending[token]) return res.send(festivalResponsePage('Invalid Link', 'This link is invalid or has expired.', false));
    if (pending[token].status !== 'pending') return res.send(festivalResponsePage('Already Processed', 'This greeting was already ' + pending[token].status + '.', false));
    var f = pending[token].festival;
    var today = new Date().toISOString().substring(0, 10);
    var log = readJSON('festival_post_log.json', {});
    log[today + '_' + f.key] = { status: 'rejected', skippedAt: new Date().toISOString(), festival: f.name };
    writeJSON('festival_post_log.json', log);
    pending[token].status = 'rejected';
    pending[token].resolvedAt = new Date().toISOString();
    writeJSON('festival_pending.json', pending);
    console.log('[Festival] Rejected/skipped: ' + f.name);
    res.send(festivalResponsePage('Skipped ❌', 'The ' + f.name + ' greeting will not be posted.', false));
  } catch(e) { res.status(500).send('Error: ' + e.message); }
});

function festivalResponsePage(title, msg, success) {
  var color = success ? '#34C759' : '#8E8E93';
  return '<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + title + '</title></head>'
    + '<body style="font-family:-apple-system,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#F5F5F7;">'
    + '<div style="text-align:center;padding:40px 24px;max-width:360px;">'
    + '<div style="font-size:56px;margin-bottom:16px;">' + (success ? '✅' : '❌') + '</div>'
    + '<div style="font-size:22px;font-weight:800;color:#1D1D1F;margin-bottom:8px;">' + title + '</div>'
    + '<div style="font-size:15px;color:#6E6E73;margin-bottom:24px;">' + msg + '</div>'
    + (success ? '<a href="https://opsaihub.in/feed.html" style="display:inline-block;background:#C8102E;color:#fff;border-radius:12px;padding:12px 24px;font-size:14px;font-weight:700;text-decoration:none;">View on Tim\'s Feed →</a>' : '')
    + '</div></body></html>';
}

function scheduleDailyFestivalCheck() {
  var now = new Date();
  var midnight = new Date(now);
  midnight.setHours(24, 1, 0, 0); // 12:01 AM next day
  var delay = midnight - now;
  setTimeout(function() {
    checkAndPostFestivalGreeting();
    scheduleDailyFestivalCheck();
  }, delay);
}

// Manual trigger + list endpoints
app.post('/api/festival/trigger', function(req, res) {
  try {
    checkAndPostFestivalGreeting();
    res.json({ success: true, message: 'Festival check triggered' });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.get('/api/festivals', function(req, res) {
  try {
    var log = readJSON('festival_post_log.json', {});
    var today = new Date().toISOString().substring(0, 10);
    var list = FESTIVALS.map(function(f) {
      var logKey = today + '_' + f.key;
      return { name: f.name, key: f.key, date: f.date, recurring: f.recurring, postedToday: !!log[logKey] };
    });
    res.json({ success: true, data: list, todaysFestivals: getFestivalToday().map(function(f){ return f.name; }) });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// Run check on server start + schedule daily
checkAndPostFestivalGreeting();
scheduleDailyFestivalCheck();

// ── Celebration Cards Engine ──────────────────────────────────────────────────
var CELEB_CARDS = [
  // Customer Love
  { id:'cl-5star',       cat:'Customer Love',    ci:'🌟', title:'5-Star Service Day!',      sub:'Guest experience was absolutely perfect',   emoji:'⭐', bg1:'#C8102E', bg2:'#7B0000', acc:'#FFD700', tag:'#GuestFirst' },
  { id:'cl-nocompl',     cat:'Customer Love',    ci:'🌟', title:'Zero Complaints Today!',    sub:"That's how we do it at Tim's 💪",           emoji:'✅', bg1:'#B71C1C', bg2:'#880000', acc:'#FFD700', tag:'#Excellence' },
  { id:'cl-comeback',    cat:'Customer Love',    ci:'🌟', title:'They Came Back Again!',     sub:'Return guests mean we\'re doing it right',  emoji:'🔄', bg1:'#8D1A1A', bg2:'#5C0000', acc:'#FFCDD2', tag:'#GuestLoyalty' },
  { id:'cl-greview',     cat:'Customer Love',    ci:'🌟', title:'New 5-Star Review!',        sub:'Google just got a little brighter ⭐⭐⭐⭐⭐', emoji:'📱', bg1:'#1565C0', bg2:'#0D47A1', acc:'#FFD700', tag:'#5Stars' },
  { id:'cl-bestcoffee',  cat:'Customer Love',    ci:'🌟', title:'Best Coffee in Town!',      sub:"Guest's exact words — own it! ☕",          emoji:'☕', bg1:'#4E342E', bg2:'#3E2723', acc:'#FFD700', tag:'#BestCoffee' },
  { id:'cl-speed',       cat:'Customer Love',    ci:'🌟', title:'Speed Record Broken!',      sub:'Fastest service time this week ⚡',         emoji:'⚡', bg1:'#1A237E', bg2:'#0D47A1', acc:'#90CAF9', tag:'#SpeedChampion' },
  { id:'cl-rush',        cat:'Customer Love',    ci:'🌟', title:'Rush Hour Crushed!',        sub:'Peak traffic. Zero compromise. Full smile',  emoji:'🚀', bg1:'#4A148C', bg2:'#311B92', acc:'#CE93D8', tag:'#QueueBuster' },
  { id:'cl-delight',     cat:'Customer Love',    ci:'🌟', title:'Guest Delight Moment!',     sub:'That genuine smile says it all 😊',         emoji:'😊', bg1:'#E65100', bg2:'#BF360C', acc:'#FFE0B2', tag:'#GuestFirst' },
  // Individual Star
  { id:'is-star',        cat:'Individual Star',  ci:'👤', title:'Star of the Week!',         sub:'You made the whole team proud',             emoji:'🌟', bg1:'#4A148C', bg2:'#6A1B9A', acc:'#FFD700', tag:'#TimsStar' },
  { id:'is-ontime',      cat:'Individual Star',  ci:'👤', title:'Always On Time!',           sub:'Punctuality is power — and you have it',    emoji:'⏰', bg1:'#1A237E', bg2:'#283593', acc:'#FFD700', tag:'#Reliability' },
  { id:'is-leader',      cat:'Individual Star',  ci:'👤', title:'Leadership Moment!',        sub:"Leading by example — the Tim's way",        emoji:'💼', bg1:'#B71C1C', bg2:'#7B0000', acc:'#FFCDD2', tag:'#Leader' },
  { id:'is-beyond',      cat:'Individual Star',  ci:'👤', title:'Above & Beyond!',           sub:'You went the extra mile today ✨',           emoji:'🏃', bg1:'#E65100', bg2:'#BF360C', acc:'#FFFFFF', tag:'#ExtraMile' },
  { id:'is-welcome',     cat:'Individual Star',  ci:'👤', title:'Welcome to the Family!',    sub:"Thrilled to have you on Tim's team 🎉",     emoji:'🤗', bg1:'#C8102E', bg2:'#8B0000', acc:'#FFD700', tag:'#WelcomeAboard' },
  { id:'is-anniv',       cat:'Individual Star',  ci:'👤', title:'Work Anniversary!',         sub:'Another year of excellence — celebrate it!', emoji:'🎂', bg1:'#880E4F', bg2:'#6A1B9A', acc:'#FFD700', tag:'#OneMoreYear' },
  { id:'is-training',    cat:'Individual Star',  ci:'👤', title:'Training Champion!',        sub:'Knowledge is the best investment 📚',        emoji:'🎓', bg1:'#1B5E20', bg2:'#2E7D32', acc:'#CCFF90', tag:'#LearningWins' },
  { id:'is-improved',    cat:'Individual Star',  ci:'👤', title:'Most Improved!',            sub:'The growth has been incredible 📈',          emoji:'📈', bg1:'#006064', bg2:'#00838F', acc:'#B2EBF2', tag:'#AlwaysGrowing' },
  // Team Power
  { id:'tp-dream',       cat:'Team Power',       ci:'👥', title:'Dream Team Moment!',        sub:'When this team clicks, magic happens ✨',   emoji:'✨', bg1:'#1A237E', bg2:'#283593', acc:'#FFD700', tag:'#DreamTeam' },
  { id:'tp-shift',       cat:'Team Power',       ci:'👥', title:'Best Shift Ever!',          sub:'That shift was absolutely electric ⚡',      emoji:'💥', bg1:'#4A148C', bg2:'#311B92', acc:'#CE93D8', tag:'#BestShift' },
  { id:'tp-fullhouse',   cat:'Team Power',       ci:'👥', title:'Full House, Full Energy!',  sub:'Packed store. Zero compromise. Top energy',  emoji:'🔥', bg1:'#C8102E', bg2:'#7B0000', acc:'#FFD700', tag:'#FullHouse' },
  { id:'tp-zerowaste',   cat:'Team Power',       ci:'👥', title:'Zero Wastage Day!',         sub:'Perfect inventory management — textbook!',   emoji:'♻️', bg1:'#1B5E20', bg2:'#2E7D32', acc:'#A5D6A7', tag:'#ZeroWaste' },
  { id:'tp-squad',       cat:'Team Power',       ci:'👥', title:'Squad Goals!',              sub:'This is exactly what teamwork looks like',   emoji:'🤝', bg1:'#006064', bg2:'#004D40', acc:'#80DEEA', tag:'#SquadGoals' },
  { id:'tp-smashed',     cat:'Team Power',       ci:'👥', title:'Goal Smashed!',             sub:'Set the target. Set it on fire. Done. 🎯',   emoji:'🎯', bg1:'#E65100', bg2:'#BF360C', acc:'#FFFFFF', tag:'#GoalCrushed' },
  { id:'tp-allin',       cat:'Team Power',       ci:'👥', title:'All Hands on Deck!',        sub:'Every single person showed up today 💪',     emoji:'💪', bg1:'#1565C0', bg2:'#0D47A1', acc:'#FFFFFF', tag:'#AllIn' },
  // Positive Review
  { id:'pr-social',      cat:'Positive Review',  ci:'⭐', title:'Social Media Shoutout!',    sub:"They posted about us — and it's amazing!",  emoji:'📸', bg1:'#C2185B', bg2:'#880E4F', acc:'#FFD700', tag:'#FeedBuzz' },
  { id:'pr-loyal',       cat:'Positive Review',  ci:'⭐', title:'Loyal Guest Milestone!',    sub:'Our regular guest just keeps coming back ☕', emoji:'🏆', bg1:'#E65100', bg2:'#BF360C', acc:'#FFD700', tag:'#LoyalGuests' },
  { id:'pr-feedback',    cat:'Positive Review',  ci:'⭐', title:'Glowing Feedback!',         sub:'Guest feedback just came in — and it shines!', emoji:'💌', bg1:'#1B5E20', bg2:'#2E7D32', acc:'#FFD700', tag:'#GuestLoves' },
  { id:'pr-wordmouth',   cat:'Positive Review',  ci:'⭐', title:'Word of Mouth Win!',        sub:'Best marketing = happy guests talking',      emoji:'🗣️', bg1:'#4A148C', bg2:'#6A1B9A', acc:'#CE93D8', tag:'#WordOfMouth' },
  { id:'pr-corp10',      cat:'Positive Review',  ci:'⭐', title:'Corporate 10/10!',          sub:'Perfect score from our corporate guests!',   emoji:'💼', bg1:'#1A237E', bg2:'#283593', acc:'#FFD700', tag:'#CorporateLove' },
  { id:'pr-trending',    cat:'Positive Review',  ci:'⭐', title:"We're Trending!",           sub:'Online buzz for all the right reasons 🔥',   emoji:'📊', bg1:'#B71C1C', bg2:'#880E4F', acc:'#FFD700', tag:'#Trending' },
  // Corporate Orders
  { id:'co-newclient',   cat:'Corporate Orders', ci:'💼', title:'New Corporate Client!',     sub:'Secured a new corporate partnership! 🤝',   emoji:'🤝', bg1:'#1A237E', bg2:'#283593', acc:'#FFD700', tag:'#CorporateWin' },
  { id:'co-regular',     cat:'Corporate Orders', ci:'💼', title:'Regular Order Nailed!',     sub:'Our corporate regulars never disappointed',  emoji:'🔄', bg1:'#0D47A1', bg2:'#1565C0', acc:'#90CAF9', tag:'#Reliable' },
  { id:'co-delivery',    cat:'Corporate Orders', ci:'💼', title:'Office Delivery Done!',     sub:'Hot, on-time and perfectly presented ☕',    emoji:'🚗', bg1:'#4E342E', bg2:'#3E2723', acc:'#FFD700', tag:'#OnTimeDelivery' },
  { id:'co-account',     cat:'Corporate Orders', ci:'💼', title:'New Account Milestone!',    sub:"Another corporate joins Tim's family",       emoji:'📋', bg1:'#1B5E20', bg2:'#2E7D32', acc:'#A5D6A7', tag:'#NewAccount' },
  { id:'co-bulk',        cat:'Corporate Orders', ci:'💼', title:'Bulk Order Executed!',      sub:"Large order fulfilled flawlessly. That's pro.", emoji:'📦', bg1:'#E65100', bg2:'#BF360C', acc:'#FFFFFF', tag:'#BulkWin' },
  // Events
  { id:'ev-storeanniv',  cat:'Events',           ci:'🎪', title:'Store Anniversary!',        sub:"Celebrating another year of Tim's best",     emoji:'🎂', bg1:'#880E4F', bg2:'#C2185B', acc:'#FFD700', tag:'#StoreAnniversary' },
  { id:'ev-activation',  cat:'Events',           ci:'🎪', title:'Brand Activation Live!',    sub:'The activation is live and buzz is real!',   emoji:'📣', bg1:'#C8102E', bg2:'#8B0000', acc:'#FFD700', tag:'#Activation' },
  { id:'ev-promo',       cat:'Events',           ci:'🎪', title:'New Promo Launched!',       sub:'Promo is live — guests are already loving it!', emoji:'🎁', bg1:'#E65100', bg2:'#F57F17', acc:'#FFFFFF', tag:'#NewPromo' },
  { id:'ev-community',   cat:'Events',           ci:'🎪', title:'Community Connect!',        sub:'Connected with our community today 🤝',       emoji:'🏘️', bg1:'#1565C0', bg2:'#0D47A1', acc:'#FFD700', tag:'#Community' },
  { id:'ev-popup',       cat:'Events',           ci:'🎪', title:'Pop-Up Was a Hit!',         sub:'The crowd loved us — and we loved them! ☕', emoji:'🚀', bg1:'#4A148C', bg2:'#311B92', acc:'#CE93D8', tag:'#PopUp' },
  { id:'ev-instore',     cat:'Events',           ci:'🎪', title:'In-Store Event Done!',      sub:'Memorable moments created at the store 🎊', emoji:'🎊', bg1:'#880E4F', bg2:'#4A148C', acc:'#FFD700', tag:'#StoreEvent' },
  // Operations
  { id:'ops-green',      cat:'Operations',       ci:'✅', title:'Checklist 100% Green!',     sub:'All boxes ticked. Perfection achieved!',     emoji:'✅', bg1:'#1B5E20', bg2:'#2E7D32', acc:'#CCFF90', tag:'#Compliant' },
  { id:'ops-audit',      cat:'Operations',       ci:'✅', title:'Audit Result: Excellent!',  sub:'The standard was set — and we crushed it 📋', emoji:'📋', bg1:'#1B5E20', bg2:'#388E3C', acc:'#FFD700', tag:'#AuditWin' },
  { id:'ops-inspect',    cat:'Operations',       ci:'✅', title:'Inspection Passed!',        sub:'Spotless store. Perfect execution ✨',         emoji:'🏆', bg1:'#006064', bg2:'#00838F', acc:'#80DEEA', tag:'#StoreStandards' },
  { id:'ops-sop',        cat:'Operations',       ci:'✅', title:'SOP 100% Compliant!',       sub:"Every standard followed — that's Tim's quality", emoji:'📌', bg1:'#0D47A1', bg2:'#1565C0', acc:'#90CAF9', tag:'#SOPChampion' },
  { id:'ops-training',   cat:'Operations',       ci:'✅', title:'Training Completed!',       sub:'Team trained and ready for anything 📚',      emoji:'📚', bg1:'#4A148C', bg2:'#6A1B9A', acc:'#CE93D8', tag:'#TeamReady' },
  // Milestones
  { id:'ms-cups',        cat:'Milestones',       ci:'🏆', title:'1,000 Cups Milestone!',     sub:'A thousand reasons to be proud this week ☕', emoji:'☕', bg1:'#BF360C', bg2:'#E64A19', acc:'#FFD700', tag:'#1000Cups' },
  { id:'ms-target',      cat:'Milestones',       ci:'🏆', title:'Month Target Hit!',         sub:"Smashed before deadline — Tim's way",        emoji:'🎯', bg1:'#1B5E20', bg2:'#2E7D32', acc:'#FFD700', tag:'#TargetSmashed' },
  { id:'ms-record',      cat:'Milestones',       ci:'🏆', title:'New Store Record!',         sub:'A new benchmark has been set — own it!',     emoji:'🏅', bg1:'#E65100', bg2:'#BF360C', acc:'#FFD700', tag:'#NewRecord' },
  { id:'ms-sales',       cat:'Milestones',       ci:'🏆', title:'Sales Milestone!',          sub:'A big number just hit the board 📊🔥',       emoji:'📊', bg1:'#1A237E', bg2:'#0D47A1', acc:'#FFD700', tag:'#SalesMilestone' },
  { id:'ms-together',    cat:'Milestones',       ci:'🏆', title:'One Year Together!',        sub:'This team has been incredible for a year 🫶', emoji:'🫶', bg1:'#880E4F', bg2:'#AD1457', acc:'#FFD700', tag:'#Grateful' },
];

function generateCelebCardSVG(c) {
  var tfs = c.title.length > 26 ? 38 : 44;
  return '<?xml version="1.0" encoding="UTF-8"?>'
    + '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">'
    + '<defs><linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">'
    + '<stop offset="0%" stop-color="' + c.bg1 + '"/><stop offset="100%" stop-color="' + c.bg2 + '"/>'
    + '</linearGradient></defs>'
    + '<rect width="800" height="800" fill="url(#bg)"/>'
    + '<circle cx="680" cy="120" r="200" fill="rgba(255,255,255,0.05)"/>'
    + '<circle cx="120" cy="680" r="220" fill="rgba(255,255,255,0.05)"/>'
    + '<circle cx="400" cy="400" r="360" fill="none" stroke="rgba(255,255,255,0.04)" stroke-width="90"/>'
    + '<rect x="24" y="24" width="752" height="752" rx="28" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1.5"/>'
    + '<text x="400" y="66" font-size="12" text-anchor="middle" fill="rgba(255,255,255,0.38)" '
    + 'font-family="Arial,sans-serif" letter-spacing="4">TIM HORTONS INDIA</text>'
    + '<rect x="288" y="82" width="224" height="30" rx="15" fill="rgba(255,255,255,0.1)" stroke="rgba(255,255,255,0.18)" stroke-width="1"/>'
    + '<text x="400" y="102" font-size="12" text-anchor="middle" fill="rgba(255,255,255,0.75)" '
    + 'font-family="Arial,sans-serif">' + escSVG(c.ci + ' ' + c.cat) + '</text>'
    + '<text x="400" y="320" font-size="130" text-anchor="middle" dominant-baseline="middle" '
    + 'font-family="Segoe UI Emoji,Noto Color Emoji,Apple Color Emoji,sans-serif">' + c.emoji + '</text>'
    + '<text x="400" y="424" font-size="' + tfs + '" font-weight="900" text-anchor="middle" fill="' + c.acc + '" '
    + 'font-family="Arial Black,Arial,sans-serif">' + escSVG(c.title) + '</text>'
    + '<text x="400" y="468" font-size="20" text-anchor="middle" fill="rgba(255,255,255,0.82)" '
    + 'font-family="Arial,sans-serif">' + escSVG(c.sub) + '</text>'
    + '<line x1="310" y1="490" x2="490" y2="490" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>'
    + '<text x="400" y="516" font-size="15" text-anchor="middle" fill="rgba(255,255,255,0.45)" '
    + 'font-family="Arial,sans-serif">' + escSVG(c.tag) + '</text>'
    + '<circle cx="400" cy="706" r="36" fill="rgba(255,255,255,0.1)" stroke="rgba(255,255,255,0.22)" stroke-width="1.5"/>'
    + '<text x="400" y="713" font-size="20" font-weight="900" text-anchor="middle" fill="white" '
    + 'font-family="Arial Black,Arial,sans-serif">TH</text>'
    + '<text x="400" y="758" font-size="12" text-anchor="middle" fill="rgba(255,255,255,0.4)" '
    + 'font-family="Arial,sans-serif">Tim\'s Ops Connect · OpsAIHub</text>'
    + '</svg>';
}

(function ensureAllCelebCards() {
  var dir = path.join(__dirname, 'public', 'images', 'celebrations');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  CELEB_CARDS.forEach(function(c) {
    var p = path.join(dir, c.id + '.svg');
    if (!fs.existsSync(p)) fs.writeFileSync(p, generateCelebCardSVG(c), 'utf8');
  });
  console.log('[CelebCards] ' + CELEB_CARDS.length + ' cards ready.');
})();

app.get('/api/celebration-cards', function(req, res) {
  try {
    res.json({ success: true, data: CELEB_CARDS.map(function(c) {
      return { id: c.id, cat: c.cat, ci: c.ci, title: c.title, sub: c.sub, emoji: c.emoji,
               bg1: c.bg1, bg2: c.bg2, acc: c.acc, tag: c.tag, url: '/images/celebrations/' + c.id + '.svg' };
    })});
  } catch(e) { res.status(500).json({ success: false, error: e.message }); }
});

// ── Edit Own Post / Comment ───────────────────────────────────────────────────
app.post('/api/posts/edit', function(req, res) {
  try {
    var posts = readJSON('posts.json', []);
    var post = posts.find(function(p) { return p.id === req.body.postId; });
    if (!post) return res.status(404).json({ success: false, error: 'Post not found' });
    post.caption = req.body.caption;
    post.editedAt = new Date().toISOString();
    writeJSON('posts.json', posts);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ success: false, error: e.message }); }
});

app.post('/api/posts/comment/edit', function(req, res) {
  try {
    var posts = readJSON('posts.json', []);
    var post = posts.find(function(p) { return p.id === req.body.postId; });
    if (!post || !post.comments) return res.status(404).json({ success: false, error: 'Not found' });
    var idx = parseInt(req.body.commentIdx);
    if (isNaN(idx) || !post.comments[idx]) return res.status(404).json({ success: false, error: 'Comment not found' });
    if (req.body.action === 'delete') {
      post.comments.splice(idx, 1);
    } else {
      post.comments[idx].text = req.body.text;
      post.comments[idx].edited = true;
    }
    writeJSON('posts.json', posts);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ success: false, error: e.message }); }
});

// ── LIVE PRESENCE ─────────────────────────────────────────────────────────
var onlineUsers = {}; // { name: lastSeenTimestamp }
var PRESENCE_TTL = 45000; // 45 seconds

app.post('/api/presence/ping', function(req, res) {
  var name = (req.body && req.body.name) ? req.body.name.trim() : '';
  if (!name || name === 'Guest') return res.json({ success: false });
  onlineUsers[name] = Date.now();
  res.json({ success: true });
});

app.get('/api/presence/online', function(req, res) {
  var now = Date.now();
  var active = Object.keys(onlineUsers).filter(function(n) {
    return (now - onlineUsers[n]) < PRESENCE_TTL;
  });
  // Clean up stale entries
  Object.keys(onlineUsers).forEach(function(n) {
    if ((now - onlineUsers[n]) >= PRESENCE_TTL * 4) delete onlineUsers[n];
  });
  res.json({ success: true, online: active, count: active.length });
});

app.listen(PORT, function() { console.log('OpsAIHub Staging running on port ' + PORT); });
module.exports = { readJSON: readJSON, writeJSON: writeJSON };
